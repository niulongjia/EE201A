#!/bin/bash

rm -rf DesignLib
rm -rf TechLib
rm *.log
rm *.o
rm lib.defs
