//Author: LONGJIA NIU
//UID: 304-590-762
//UCLA EE 201A Lab 1

// *****************************************************************************
// HelloWorld.cpp
//
// The following tasks are performed by this program
//  1. Derive an oaTech observer to handle conflicts in the technology hierarchy
//  2. Derive an oaLibDefsList observer to handle warnings related to lib.defs
//  3. Open the design
//  4. Print the library name
//  5. Print the cell name
//  6. Print the view name
//  7. Create nets with the names "Hello" and "World"
//  8. Save these nets
//  9. Run the net iterator and print the existing nets in the design
//
// ****************************************************************************
// Except as specified in the OpenAccess terms of use of Cadence or Silicon
// Integration Initiative, this material may not be copied, modified,
// re-published, uploaded, executed, or distributed in any way, in any medium,
// in whole or in part, without prior written permission from Cadence.
//
//                Copyright 2002-2005 Cadence Design Systems, Inc.
//                           All Rights Reserved.
//
// To distribute any derivative work based upon this file you must first contact
// Si2 @ contracts@si2.org.
//
// *****************************************************************************
// *****************************************************************************

#include <iostream>
#include "oaDesignDB.h"

#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonTechObserver.h"
#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonLibDefListObserver.h"
#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonFunctions.h"


using namespace oa;
using namespace std;

static oaNativeNS ns;




// ****************************************************************************
// printDesignNames()
//
// This function gets the library, cell and view names associated with the open
// design and prints them.
// ****************************************************************************
void
printDesignNames(oaDesign *design)
{
    oaString    libName;
    oaString    cellName;
    oaString    viewName;

    // Library, cell and view names are obtained.
    design->getLibName(ns, libName);
    design->getCellName(ns, cellName);
    design->getViewName(ns, viewName);

    // Library, cell and view names are printed.
    cout << "\tThe library name for this design is : " << libName << endl;
    cout << "\tThe cell name for this design is : " << cellName << endl;
    cout << "\tThe view name for this design is : " << viewName << endl;
    
    /*
        oaInt8 Int=8;
        cout << "\t" << Int << endl;
        oaString string="EE201A";
        cout << "\t" << string << endl;
        oaString string("EE201A");
        cout << "\t" << string << endl;
    */
    
}



// ****************************************************************************
// void printNets()
//  
//  This function invokes the net iterator for the design and prints the names
//  of the nets one by one.
// ****************************************************************************
oaInt8 
printNets(oaDesign *design)
{
    // Get the TopBlock of the current design
    oaBlock *block = design->getTopBlock();
    oaInt8 NetSum=0;
    oaInt8 count=0;
    if (block) {
        oaString        netName;
        oaString        InstTermName;
        oaString        TermName;
        //cout << "The following nets exist in this design." << endl;
        // Iterate over all nets in the design
        oaIter<oaNet>   netIterator(block->getNets());
        while (oaNet * net = netIterator.getNext()) {
            net->getName(ns, netName);
            
           // cout << "\t" << " < "<< netName << " > " << " InstTermName: ";
                oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());
                while (oaInstTerm *InstTerm = InstTermIterator.getNext())
                {
                  InstTerm->getTermName(ns,InstTermName);
            //    cout << InstTermName << " ";
                  count=count+1;
                }                
            //    cout << "\t" << " < " <<netName << " > " << " TermName: ";
                oaIter<oaTerm> TermIterator(net->getTerms());
                while (oaTerm *Term = TermIterator.getNext())
                {
                  Term->getName(ns,TermName);
                  //cout << TermName << " ";
                  
                }                               
            NetSum=NetSum+1;


        }

    } else {
        cout << "There is no block in this design" << endl;
    }
    return NetSum;
}






// ****************************************************************************
// main()
//
// This is the top level function that opens the design, prints library, cell,
// and view names, creates nets, and iterates the design to print the net 
// names.
// ****************************************************************************
int
main(int    argc,
     char   *argv[])
{
    try {
        // Initialize OA with data model 3, since incremental technology
        // databases are supported by this application.
        oaDesignInit(oacAPIMajorRevNumber, oacAPIMinorRevNumber, 3);

        oaString                libPath("./DesignLib");
        oaString                library("DesignLib");
	oaViewType      	*viewType = oaViewType::get(oacMaskLayout);
        oaString        	cell("s1196_bench");
       	oaString        	view("layout"); 
	oaScalarName            libName(ns,
                                        library);
        oaScalarName            cellName(ns,
                                         cell);
        oaScalarName            viewName(ns,
                                         view);
	oaScalarName    	libraryName(ns,library);
        // Setup an instance of the oaTech conflict observer.
        opnTechConflictObserver myTechConflictObserver(1);

        // Setup an instance of the oaLibDefList observer.
        opnLibDefListObserver   myLibDefListObserver(1);

        // Read in the lib.defs file.
	oaLib *lib = oaLib::find(libraryName);

        if (!lib) {
            if (oaLib::exists(libPath)) {
                // Library does exist at this path but was not in lib.defs
                lib = oaLib::open(libraryName, libPath);
            } else {
            char *DMSystem=getenv("DMSystem");
            if(DMSystem){
                    lib = oaLib::create(libraryName, libPath, oacSharedLibMode, DMSystem);
                } else {
                    lib = oaLib::create(libraryName, libPath);
                }
            }
            if (lib) {
                // We need to update the user's lib.def file since we either
                // found or created the library without a lib.defs reference.
                updateLibDefsFile(libraryName, libPath);
            } else {
                // Print error mesage 
                cerr << "ERROR : Unable to create " << libPath << "/";
                cerr << library << endl;
                return(1);
            }
        }
	// Create the design with the specified viewType,
        // Opening it for a 'write' operation.
        cout << "The design is created and opened in 'write' mode." << endl;

        oaDesign    *design = oaDesign::open(libraryName, cellName, viewName,
                                             viewType, 'r');

        // The library, cell, and view names are printed.
        printDesignNames(design);
		  oaInt8 Int=printNets(design);

	// Get the TopBlock for this design.
        oaBlock *block = design->getTopBlock();
	
	// If no TopBlock exist yet then create one.
        if (!block) {
            block = oaBlock::create(design);
        }

	//EE 201A Lab 1 Problem 2_Term starts here

cout << endl << "----- LONGJIA NIU: Problem 2 -----" << endl;     
    int fanout_Num=0;
    int fanout_Sum=0;
    int Array[20]={0};
    if (block) {
        oaString        netName;
        oaString        InstTermName;
        oaString        TermName;
        //cout << "The following nets exist in this design." << endl;
        // Iterate over all nets in the design
        oaIter<oaNet>   netIterator(block->getNets());
        while (oaNet * net = netIterator.getNext()) {
                    
                if( (net->getSigType()==0) && (net->getInstTerms().getCount()>1) && (net->getTerms().getCount()==0) )
                {
                  net->getName(ns, netName);
  
                 // cout << " < " << netName << " >: ";
                        oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());     
                        while ( oaInstTerm *InstTerm = InstTermIterator.getNext())
                        {
                        InstTerm->getTermName(ns,InstTermName);
                  //      cout << InstTermName << " ";
                        }    
                  fanout_Sum = fanout_Sum+net->getInstTerms().getCount()-1;
                  fanout_Num=fanout_Num+1; 
                  
                  // cout<< " <InstTerm_getCount>: " << net->getInstTerms().getCount() <<endl; 
                   
                  
                  Array[net->getInstTerms().getCount()-1]
                  =Array[net->getInstTerms().getCount()-1]+1;
                } 
                
                if ((net->getSigType()==0) && (net->getTerms().getCount()>0) )
                {
                        int sign=1;
                        oaIter<oaTerm> TermIterator(net->getTerms());
                        oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());
                        while (oaTerm *Term = TermIterator.getNext())
                        {
                          if (Term->getTermType()==0) {sign=0; break;} // Term indicated as Input, Discard                     
                        }
                        if (sign==1)
                        {
                        net->getName(ns, netName);
                      //  cout << " <*** " << netName << " ***>: ";
                           while ( oaInstTerm *InstTerm = InstTermIterator.getNext())
                           {
                            InstTerm->getTermName(ns,InstTermName);
                      //       cout << InstTermName << " ";                      
                            }
                            
                            oaIter<oaTerm> TermIterator_again(net->getTerms());
                           while ( oaTerm *Term_again = TermIterator_again.getNext())
                           {
                             Term_again->getName(ns,TermName);
                      //       cout<< " ***: " << TermName << " ";                         
                            }
                         fanout_Sum = fanout_Sum+net->getInstTerms().getCount()+net->getTerms().getCount()-1;
                         fanout_Num=fanout_Num+1; 
                      //   cout<< " <***InstTerm+Term_getCount***>: " << net->getInstTerms().getCount()+ net->getTerms().getCount()<<endl;
                         Array[net->getInstTerms().getCount()+ net->getTerms().getCount()-1]
                         =Array[net->getInstTerms().getCount()+ net->getTerms().getCount()-1]+1;
                        }
                        
                    
                }
                
           
        }
       // cout<< "Net_Total:" << fanout_Num <<endl;
       // cout<< "fanout_Sum:" << fanout_Sum <<endl;
       /* for (int i=0; i<20; i++)
         {
          cout<<"FanOut_" <<i<<" "<<Array[i]<<endl;
         }
        */
    } else {
        cout << "There is no block in this design" << endl;
    }
   
   cout << "Problem 2 -- Average fanout " << ((double)fanout_Sum)/((double)fanout_Num) << endl;
//////////////////////////////////////////////////////////////////////////////

	//EE 201A Lab 1 Problem 3 starts here
 
	cout << endl << "----- LONGJIA NIU: Problem 3 -----" << endl;
       int InstSum=0;
       
        int InstTerm=0;
        int Sum_II=0;
        int Sum_IT=0;
        int Temp=0;
        int IT_Num=0;
        int II_Num=0;
        int Array_II[20]={0};
        int Array_IT[10]={0};
       oaPoint Point;
      if (block) {
        oaString        netName;

        cout << "The following nets exist in this design." << endl;
/*
        oaIter<oaInst>   InstIterator(block->getInsts());
        while (oaInst * Inst = InstIterator.getNext()) {
            Inst->getName(ns, netName);
            Inst->getOrigin(Point);
           // cout << netName << " " ;
           // cout << "<" << Point.x()<< " " << Point.y() << "> " << endl;
            
            InstSum=InstSum+1;
        }
        cout<< "\tTotal number of Inst:" << InstSum <<endl;
*/        
        /////
        oaPoint Point_1;
        oaPoint Point_2;

        
        oaIter<oaNet>  netIterator(block->getNets());
        oaBox Box;
        oaPoint Point_InstTerm;
        oaPoint Point_Term;

        while (oaNet * net = netIterator.getNext()) {
                  Temp=0;
               

                if(net->getInstTerms().getCount()==2) 
                {           
                oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());
                
                oaInstTerm *InstTerm_1 = InstTermIterator.getNext();                       
                oaInst *Inst_1= InstTerm_1->getInst();
                Inst_1->getOrigin(Point_1);
              //  cout << "<" << Point_1.x()<< " " << Point_1.y() << "> " << "\t";

                oaInstTerm *InstTerm_2 = InstTermIterator.getNext();                
                oaInst *Inst_2= InstTerm_2->getInst();
                Inst_2->getOrigin(Point_2);
              //  cout << "<" << Point_2.x()<< " " << Point_2.y() << ">: " << "\t";
                Temp=   ( (Point_1.x()>Point_2.x()) ? Point_1.x()-Point_2.x(): Point_2.x()-Point_1.x() ) 
                         + ( (Point_1.y()>Point_2.y()) ? Point_1.y()-Point_2.y(): Point_2.y()-Point_1.y() );
                Sum_II=Sum_II + Temp;
                              
           
                 II_Num=II_Num+1;   
                 for (int i=0; i<18; i++)
                   {
                     if ( (i*1500<=Temp) && (Temp<(i+1)*1500))
                     {
                      Array_II[i]=Array_II[i]+1;
                     }
    
                    }  
             //    cout<<"Temp_II:   "<<Temp<<endl;
                }   
                if ( net->getInstTerms().getCount()==1 && net->getTerms().getCount()==1)
                {
                  oaIter<oaTerm> TermIterator(net->getTerms());
                  oaTerm *Term = TermIterator.getNext();  
                  oaIter<oaPin>  PinIterator(Term->getPins());
                  oaPin *Pin = PinIterator.getNext();
                  oaIter<oaPinFig> PinFigIterator(Pin->getFigs());
                  oaPinFig *PinFig = PinFigIterator.getNext();
                  PinFig->getBBox(Box);
                  Box.getCenter(Point_Term);

                oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());
                oaInstTerm *InstTerm = InstTermIterator.getNext();  
                oaInst *Inst_IT = InstTerm->getInst();
                Inst_IT->getOrigin(Point_InstTerm);
                
              //  cout << "Term + InstTerm: <" << Point_Term.x()<< " " << Point_Term.y() << "> " << " ";
              //  cout << "<" << Point_InstTerm.x()<< " " << Point_InstTerm.y() << "> " <<endl;
                Temp=           ( (Point_InstTerm.x()>Point_Term.x()) ? 
                                 Point_InstTerm.x()-Point_Term.x(): Point_Term.x()-Point_InstTerm.x() ) 
                              + ( (Point_InstTerm.y()>Point_Term.y()) ? 
                                 Point_InstTerm.y()-Point_Term.y(): Point_Term.y()-Point_InstTerm.y() ); 
                Sum_IT=Sum_IT +  Temp;
               // cout<<"  Temp_IT: "<<Temp<<endl; 
                IT_Num=IT_Num+1;     
                  for (int i=0; i<18; i++)
                   {
                     if ( (i*1500<=Temp) && (Temp<(i+1)*1500))
                     {
                      Array_II[i]=Array_II[i]+1;
                     }
                     if ((41000+i*1000<=Temp) && (Temp<41000+(i+1)*1000)&& (i<10))
                     {
                       Array_IT[i]=Array_IT[i]+1;
                     }
                    }         
                } 
    
        }
 
        ////// 
        
    } else {
        cout << "There is no block in this design" << endl;
    }

  //////////////////////////////////////////////////////////////////////////  
	//Output answers:
               /*   for (int i=0; i<18; i++)
                 {
                     cout<<"["<<i*1500<<" , "<<(i+1)*1500<<"): "<<Array_II[i]<<endl;
    
                  } 
                  for (int i=0; i<10; i++)
                 {
                     cout<<"["<<41000+i*1000<<" , "<<41000+(i+1)*1000<<"): "<<Array_IT[i]<<endl;
    
                  } */
	cout << "Problem 3 -- Average wirelength " << (double)((Sum_IT+Sum_II)/(IT_Num+II_Num)) << endl;

        // The design is closed.   
        design->close();

        // The library is closed.   
        lib->close();

    } catch (oaCompatibilityError &ex) {
        handleFBCError(ex);
        exit(1);

    } catch (oaException &excp) {
        cout << "ERROR: " << excp.getMsg() << endl;
        exit(1);
    }

    return 0;
}
