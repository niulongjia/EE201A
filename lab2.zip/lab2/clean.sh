#!/bin/bash

rm rc.cmd*
rm rc.log*
rm -rf fv
rm -rf sdc
echo "Not removing output/ subdirectory for fear of deleting something important that you need. You should clean it up yourself."
