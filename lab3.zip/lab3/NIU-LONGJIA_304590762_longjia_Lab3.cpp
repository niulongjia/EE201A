//Author: LONGJIA NIU
//UID: 304-590-762
//UCLA EE 201A Lab 3

// *****************************************************************************
// HelloWorld.cpp
//
// The following tasks are performed by this program
//  1. Derive an oaTech observer to handle conflicts in the technology hierarchy
//  2. Derive an oaLibDefsList observer to handle warnings related to lib.defs
//  3. Open the design
//  4. Print the library name
//  5. Print the cell name
//  6. Print the view name
//  7. Create nets with the names "Hello" and "World"
//  8. Save these nets
//  9. Run the net iterator and print the existing nets in the design
//
// ****************************************************************************
// Except as specified in the OpenAccess terms of use of Cadence or Silicon
// Integration Initiative, this material may not be copied, modified,
// re-published, uploaded, executed, or distributed in any way, in any medium,
// in whole or in part, without prior written permission from Cadence.
//
//                Copyright 2002-2005 Cadence Design Systems, Inc.
//                           All Rights Reserved.
//
// To distribute any derivative work based upon this file you must first contact
// Si2 @ contracts@si2.org.
//
// *****************************************************************************
// *****************************************************************************
#include <iostream>
#include <string>
#include "oaDesignDB.h"

#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonTechObserver.h"
#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonLibDefListObserver.h"
#include "/w/class/ee201a/ee201ata/oa/examples/oa/common/commonFunctions.h"
using namespace oa;
using namespace std;
static oaNativeNS ns;
// ****************************************************************************
// printDesignNames()
//
// This function gets the library, cell and view names associated with the open
// design and prints them.
// ****************************************************************************
void
printDesignNames(oaDesign *design)
{
    oaString    libName;
    oaString    cellName;
    oaString    viewName;

    // Library, cell and view names are obtained.
    design->getLibName(ns, libName);
    design->getCellName(ns, cellName);
    design->getViewName(ns, viewName);

    // Library, cell and view names are printed.
    cout << "\tThe library name for this design is : " << libName << endl;
    cout << "\tThe cell name for this design is : " << cellName << endl;
    cout << "\tThe view name for this design is : " << viewName << endl;
}
// ****************************************************************************
// void printNets()
//  
//  This function invokes the net iterator for the design and prints the names
//  of the nets one by one.
// ****************************************************************************
void
printNets(oaDesign *design)
{
    // Get the TopBlock of the current design
    oaBlock *block = design->getTopBlock();
    int count_allNet=0;
    if (block) 
    {
        oaString        netName;
        //cout << "The following nets exist in this design." << endl;
        // Iterate over all nets in the design
        oaIter<oaNet>   netIterator(block->getNets());
        while (oaNet * net = netIterator.getNext()) 
        {
            net->getName(ns, netName);
           // cout << "\t" << netName << " " << net->getTerms().getCount() <<" "<<net->getInstTerms().getCount()<<endl;
           cout << "\t" << netName <<endl;
           count_allNet=count_allNet+1;
        }
        //cout<<"count_allNet: "<<count_allNet<<endl;
    } 
    else 
    {
        cout << "There is no block in this design" << endl;
    }
}


// ****************************************************************************
// Author: NIU-LONGJIA
// int HPWL_Calc(oaBock *block)
// This is the function for computing HPWL for problem 1 and problem 2
// ****************************************************************************
int
HPWL_Calc(oaBlock *block)
{
      int count=0;
      int x_min=0;
      int y_min=0;
      int x_max=0;
      int y_max=0;
      oaPoint Point;
      int HPWL=0;
      int temp=0;
      
      oaBox Box;
    if (block) 
    {
        // Iterate over all nets in the design
        oaIter<oaNet>   netIterator(block->getNets());
        while (oaNet * net = netIterator.getNext()) 
        {
    
           oaIter<oaInstTerm> InstTermIterator(net->getInstTerms());
           oaInstTerm *InstTerm = InstTermIterator.getNext();
           oaInst *Inst= InstTerm->getInst();
           Inst->getOrigin(Point);
               x_min=Point.x();
               x_max=Point.x();
               y_min=Point.y();
               y_max=Point.y();

           while (oaInstTerm *InstTerm = InstTermIterator.getNext())
               {
               oaInst *Inst= InstTerm->getInst();
               Inst->getOrigin(Point);
                if (Point.x()<x_min) {x_min=Point.x();}
                if (Point.x()>x_max) {x_max=Point.x();}
                if (Point.y()<y_min) {y_min=Point.y();}
                if (Point.y()>y_max) {y_max=Point.y();}
               }
               
          if (net->getTerms().getCount()>0)
           {           
            oaIter<oaTerm> TermIterator(net->getTerms());

               while (oaTerm *Term = TermIterator.getNext())
                 {

                  oaIter<oaPin>  PinIterator(Term->getPins());
                  oaPin *Pin = PinIterator.getNext();
                  oaIter<oaPinFig> PinFigIterator(Pin->getFigs());
                  oaPinFig *PinFig = PinFigIterator.getNext();
                  PinFig->getBBox(Box);
                  Box.getCenter(Point);
               
                  if (Point.x()<x_min) {x_min=Point.x();}
                  if (Point.x()>x_max) {x_max=Point.x();}
                  if (Point.y()<y_min) {y_min=Point.y();}
                  if (Point.y()>y_max) {y_max=Point.y();}
                  
                 }
           } 
           HPWL=HPWL+(x_max-x_min)+(y_max-y_min);
           
        }// the end of [ while (oaNet * net = netIterator.getNext()) ]

      // cout<<"HPWL: "<<HPWL<<endl;
      }
     else 
     {
        cout << "There is no block in this design" << endl;
     }

    return HPWL;
}

int* HPWL_Calc_Increment_LockNone(oaBlock *block, int HPWL_Original)
{ 
        int count_Inst=0;
        
        int p=0;
        int q=0;
        int times=0;
        oaPoint Point;
  
      int x_min=0;
      int y_min=0;
      int x_max=0;
      int y_max=0;

      int max_decrease_p=0;
      int max_decrease_q=0;

      int HPWL_min=HPWL_Original;
      int sign=0;
      int *result=new int[2];
    ///////////////// Calculate total number of Inst ///////////////////

            count_Inst = block->getInsts().getCount();
            //cout<<"count_Inst: "<<count_Inst<<endl;
            oaInst **Inst_Array = new oaInst* [count_Inst+1];
            int *Orientation = new int[count_Inst+1];
            oaString *CellName = new oaString[count_Inst+1];
            

      //////////////// Store *Inst into Inst_Array[] /////////////////     
           int i=0; 
           oaIter<oaInst>  InstIterator(block->getInsts());
           while (oaInst *Inst = InstIterator.getNext()) 
            {
              //oaString        Inst_Name;
              oaString        InstCellName;
              
             //Inst->getName(ns, Inst_Name);
             Inst->getCellName(ns,InstCellName);
             
             i=i+1;
                         
             Inst_Array[i]=Inst;
             Orientation[i]=Inst->getOrient();
             CellName[i]=InstCellName;

             
            }
      ////////////////// Swap instances /////////////////////// 

            for(p=1;p<=count_Inst;p++)
            {
              max_decrease_p=0;
              max_decrease_q=0;
              for(q=1;q<=count_Inst;q++)
              {

              if (
                  (p!=q)&&(CellName[p]==CellName[q])&&( Orientation[p]==Orientation[q] )
                 )
                                
                {

                  ////////// Swap //////////////
                                    
                  oaPoint Point1_temp;
                  oaPoint Point2_temp;    
                  Inst_Array[p]->getOrigin(Point1_temp);
                  Inst_Array[q]->getOrigin(Point2_temp); 
                  Inst_Array[q]->setOrigin(Point1_temp);                          
                  Inst_Array[p]->setOrigin(Point2_temp);
                  
                  int HPWL_temp=HPWL_Calc(block);
                  
                  Inst_Array[p]->setOrigin(Point1_temp);
                  Inst_Array[q]->setOrigin(Point2_temp);   
                   
                   if (HPWL_temp<HPWL_min)
                    {
                    max_decrease_p=p;
                    max_decrease_q=q;
                    HPWL_min=HPWL_temp;
                    times=times+1;
                   
                    }
                
                }// end of if
                
                
              }// end of q

            if (max_decrease_p>0)
                {
                    oaPoint Point1_temp;
                    oaPoint Point2_temp;

                    Inst_Array[max_decrease_p]->getOrigin(Point1_temp);
                    Inst_Array[max_decrease_q]->getOrigin(Point2_temp);  
                    Inst_Array[max_decrease_q]->setOrigin(Point1_temp);                                
                    Inst_Array[max_decrease_p]->setOrigin(Point2_temp);
                    
                   //cout<<"p: "<<p<<" q: "<<q<<" max_decrease_p: "<<max_decrease_p<<" max_decrease_q: "<<max_decrease_q<<" HPWL_Increment: "<<HPWL_min<<endl;
                    
                 } //end of if(max_decrease>0) 
                 
             
            }// end of p

           
         //cout<<"***times***:"<<times<<endl;    
         //cout<<"HPWL_after:"<<HPWL_min<<endl;  
         //cout<<"sign: "<<sign<<endl;
         result[0]=HPWL_min; result[1]=times;
         return result;
         
}

int* HPWL_Calc_Increment_LockAll(oaBlock *block,int HPWL_Original)
{
  
        int count_Inst=0;
        
        int p=0;
        int q=0;
        int times=1;
        oaPoint Point;

        int sign=0;
        
      int count=0;
      int x_min=0;
      int y_min=0;
      int x_max=0;
      int y_max=0;
      int HPWL_p=0;
      int HPWL_q=0;
      int HPWL_p_after=0;
      int HPWL_q_after=0;
      int max_decrease_p=0;
      int max_decrease_q=0;
      int max_decrease=0;
      int sum_decrease=0;
      
      int *result=new int [2];
      int swap_times=0;
        if (block) 
        {

    ///////////////// Calculate total number of Inst ///////////////////

            count_Inst = block->getInsts().getCount();
             
            //cout<<"count_Inst: "<<count_Inst<<endl;
            oaInst **Inst_Array = new oaInst* [count_Inst+1];
            int *Orientation = new int[count_Inst+1];
            oaString *CellName = new oaString[count_Inst+1];
            int *PlacementStatus = new int[count_Inst+1];
            
            //InstIterator.reset();

      //////////////// Store *Inst into Inst_Array[] /////////////////     
           int i=0; 
           oaIter<oaInst>  InstIterator(block->getInsts());
           while (oaInst *Inst = InstIterator.getNext()) 
            {
              oaString        Inst_Name;
              oaString        InstCellName;
              
             Inst->getName(ns, Inst_Name);
             Inst->getCellName(ns,InstCellName);
             
             i=i+1;
             
             Inst_Array[i]=Inst;
             Orientation[i]=Inst->getOrient();
             CellName[i]=InstCellName;
             PlacementStatus[i]=Inst->getPlacementStatus();
             
            }

      ////////////////// Swap instances /////////////////////// 
      for(times=1;;times=times+1)
          {
          max_decrease_p=0;
          max_decrease_q=0;
          max_decrease=0;
         
         // cout<<endl;  
         // cout<<"times: "<<times<<endl;
            for(p=1;p<=count_Inst;p++)
            {

              for(q=p+1;q<=count_Inst;q++)
              {

              if (
                  (CellName[p]==CellName[q])
                &&( Orientation[p]==Orientation[q] )
                &&( Inst_Array[p]->getPlacementStatus()==2 )
                &&( Inst_Array[q]->getPlacementStatus()==2 )
                 )
                                
                {
                  ////////// Before Swap //////////////
                  HPWL_p=0;
                  HPWL_q=0;

                  oaIter<oaInstTerm> InstTermIter_p(Inst_Array[p]->getInstTerms());                  
                  while (oaInstTerm *InstTerm_p = InstTermIter_p.getNext())
                    {
                      oaNet *Net_p = InstTerm_p->getNet(true);                     

                      oaIter<oaInstTerm> ITIter(Net_p->getInstTerms());

                        oaInstTerm *IT = ITIter.getNext();
                        oaInst *I = IT->getInst();
                        oaPoint P;
                        
                        I->getOrigin(P);
                        x_min=P.x();
                        y_min=P.y();
                        x_max=P.x();
                        y_max=P.y(); 
 
                        while (oaInstTerm *IT = ITIter.getNext())
                         {
                           oaInst *I = IT->getInst();
                           oaPoint P;
                           I->getOrigin(P);
                           if (P.x()<x_min) {x_min=P.x();}
                           if (P.x()>x_max) {x_max=P.x();}
                           if (P.y()<y_min) {y_min=P.y();}
                           if (P.y()>y_max) {y_max=P.y();}                            
                         }
                      if (Net_p->getTerms().getCount()>0)// >0 Terms
                      {
                        oaBox Box;
                        oaPoint P;
                        
                        oaIter<oaTerm> TIter(Net_p->getTerms());
                        oaTerm *T = TIter.getNext();
                        oaIter<oaPin>  PinIter(T->getPins());
                        oaPin *Pin = PinIter.getNext();
                        oaIter<oaPinFig> PinFigIter(Pin->getFigs());
                        oaPinFig *PinFig = PinFigIter.getNext();
                        PinFig->getBBox(Box);
                        Box.getCenter(P);
                        
                           if (P.x()<x_min) {x_min=P.x();}
                           if (P.x()>x_max) {x_max=P.x();}
                           if (P.y()<y_min) {y_min=P.y();}
                           if (P.y()>y_max) {y_max=P.y();}  

                        
                      }
                      
                      HPWL_p=HPWL_p+(x_max-x_min)+(y_max-y_min);

                    }              

                  oaIter<oaInstTerm> InstTermIter_q(Inst_Array[q]->getInstTerms());
                  while (oaInstTerm *InstTerm_q = InstTermIter_q.getNext())
                    {
                      oaNet *Net_q = InstTerm_q->getNet(true);
                      
                      oaString test;
                      Net_q->getName(ns,test);

                        oaIter<oaInstTerm> ITIter(Net_q->getInstTerms());
                        oaInstTerm *IT = ITIter.getNext();
                        oaInst *I = IT->getInst();

                        oaPoint P;
                        I->getOrigin(P);
                        x_min=P.x();
                        y_min=P.y();
                        x_max=P.x();
                        y_max=P.y(); 

                      while (oaInstTerm *IT = ITIter.getNext())
                       {
                         oaInst *I = IT->getInst(); 
                         oaPoint P;
                         I->getOrigin(P);
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}
                         
                       } 
                      
                      if (Net_q->getTerms().getCount()>0)// >0 Terms
                      {
                        oaBox Box;
                        oaPoint P;
                        
                        oaIter<oaTerm> TIter(Net_q->getTerms());
                        oaTerm *T = TIter.getNext();
                        oaIter<oaPin>  PinIter(T->getPins());
                        oaPin *Pin = PinIter.getNext();
                        oaIter<oaPinFig> PinFigIter(Pin->getFigs());
                        oaPinFig *PinFig = PinFigIter.getNext();
                        PinFig->getBBox(Box);
                        Box.getCenter(P);
                        
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}

                        
                      }
                      HPWL_q=HPWL_q+(x_max-x_min)+(y_max-y_min);
                    }// end of iteration of net
                   
                   // cout<<" HPWL before swap: "<<"<HPWL_p> " <<HPWL_p<<" "<<"<HPWL_q> "<<HPWL_q<<" "<<"<HPWL_p+HPWL_q> "<<HPWL_p+HPWL_q<<endl;
                  
                  
                  ////////// After Swap //////////////
                  HPWL_p_after=0;
                  HPWL_q_after=0;
                  
                  
                  oaPoint Point1_temp;
                  oaPoint Point2_temp;    
                  Inst_Array[p]->getOrigin(Point1_temp);
                  Inst_Array[q]->getOrigin(Point2_temp); 
                  Inst_Array[q]->setOrigin(Point1_temp);                          
                  Inst_Array[p]->setOrigin(Point2_temp);
                  


                  
                  oaIter<oaInstTerm> InstTermIter_p_after(Inst_Array[p]->getInstTerms());                  
                  while (oaInstTerm *InstTerm_p_after = InstTermIter_p_after.getNext())
                    {
                      oaNet *Net_p_after = InstTerm_p_after->getNet(true);


                      oaIter<oaInstTerm> ITIter(Net_p_after->getInstTerms());
                        oaInstTerm *IT = ITIter.getNext();
                        oaInst *I = IT->getInst();

                        oaPoint P;
                        I->getOrigin(P);
                        x_min=P.x();
                        y_min=P.y();
                        x_max=P.x();
                        y_max=P.y(); 
                 

                      while (oaInstTerm *IT = ITIter.getNext())
                       {
                         oaInst *I = IT->getInst();
                         oaPoint P;
                         I->getOrigin(P);
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}

                       }
                      if (Net_p_after->getTerms().getCount()>0)// >0 Terms
                      {
                        oaBox Box;
                        oaPoint P;
                        
                        oaIter<oaTerm> TIter(Net_p_after->getTerms());
                        oaTerm *T = TIter.getNext();
                        oaIter<oaPin>  PinIter(T->getPins());
                        oaPin *Pin = PinIter.getNext();
                        oaIter<oaPinFig> PinFigIter(Pin->getFigs());
                        oaPinFig *PinFig = PinFigIter.getNext();
                        PinFig->getBBox(Box);
                        Box.getCenter(P);
                        
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}                      
                      }
                      HPWL_p_after=HPWL_p_after+(x_max-x_min)+(y_max-y_min);

                    }
                    
                    oaIter<oaInstTerm> InstTermIter_q_after(Inst_Array[q]->getInstTerms());
                    while (oaInstTerm *InstTerm_q_after = InstTermIter_q_after.getNext())
                    {
                      oaNet *Net_q_after = InstTerm_q_after->getNet(true);
                      
                      oaIter<oaInstTerm> ITIter(Net_q_after->getInstTerms());

                        //oaIter<oaInstTerm> ITIter(Net_p->getInstTerms());
                        oaInstTerm *IT = ITIter.getNext();
                        oaInst *I = IT->getInst();
                        //I->getName(ns,test);
                        //cout<<test<<endl;
                        oaPoint P;
                        I->getOrigin(P);
                        x_min=P.x();
                        y_min=P.y();
                        x_max=P.x();
                        y_max=P.y(); 

                      while (oaInstTerm *IT = ITIter.getNext())
                       {
                         oaInst *I = IT->getInst();
                         oaPoint P;
                         I->getOrigin(P);
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}

                       }
                     if (Net_q_after->getTerms().getCount()>0)// >0 Terms
                      {
                        oaBox Box;
                        oaPoint P;
                        
                        oaIter<oaTerm> TIter(Net_q_after->getTerms());
                        oaTerm *T = TIter.getNext();
                        oaIter<oaPin>  PinIter(T->getPins());
                        oaPin *Pin = PinIter.getNext();
                        oaIter<oaPinFig> PinFigIter(Pin->getFigs());
                        oaPinFig *PinFig = PinFigIter.getNext();
                        PinFig->getBBox(Box);
                        Box.getCenter(P);
                        
                         if (P.x()<x_min) {x_min=P.x();}
                         if (P.x()>x_max) {x_max=P.x();}
                         if (P.y()<y_min) {y_min=P.y();}
                         if (P.y()>y_max) {y_max=P.y();}
                       
                      }
                      HPWL_q_after=HPWL_q_after+(x_max-x_min)+(y_max-y_min);

                    }
                
                  
                    Inst_Array[p]->getOrigin(Point1_temp);
                    Inst_Array[q]->getOrigin(Point2_temp);     
                    Inst_Array[q]->setOrigin(Point1_temp);                                           
                    Inst_Array[p]->setOrigin(Point2_temp);
                    
                   if ((HPWL_p_after+HPWL_q_after)<(HPWL_p+HPWL_q))
                   {
                   
                     if ( (HPWL_p+HPWL_q)-(HPWL_p_after+HPWL_q_after)>max_decrease)
                     {
                       max_decrease_p=p;
                       max_decrease_q=q;
                       max_decrease=(HPWL_p+HPWL_q)-(HPWL_p_after+HPWL_q_after);
                     }
                     
                     //  cout<<times<<" "<<p<<" "<<q<<" difference:"<<(HPWL_p+HPWL_q)-(HPWL_p_after+HPWL_q_after)<<endl;
                   }
                  
                  
                }// end of if
                
                if (sign==1) break;
              }// end of q
              
              if (sign==1) break;
            }// end of p
            if (max_decrease==0) break;     
            if (max_decrease>0)
                {
                    oaPoint Point1_temp;
                    oaPoint Point2_temp;

                    Inst_Array[max_decrease_p]->getOrigin(Point1_temp);
                    Inst_Array[max_decrease_q]->getOrigin(Point2_temp);  
                    Inst_Array[max_decrease_q]->setOrigin(Point1_temp);                                
                    Inst_Array[max_decrease_p]->setOrigin(Point2_temp);
                   
                   swap_times++; 
                   
                  // cout<<"p: "<<p<<" q: "<<q<<" max_decrease_p: "<<max_decrease_p<<" max_decrease_q: "<<max_decrease_q<<" max_decrease: "<<max_decrease<<endl;
           
                   oaPlacementStatus PS(oacLockedPlacementStatus);
                   Inst_Array[max_decrease_p]->setPlacementStatus(PS);//PlacementStatus[max_decrease_p]=4;
                   Inst_Array[max_decrease_q]->setPlacementStatus(PS);//PlacementStatus[max_decrease_q]=4;
                    
                   sum_decrease=sum_decrease+max_decrease;  
                   
                   oaIter<oaInstTerm> InstTermIter_p_lock(Inst_Array[max_decrease_p]->getInstTerms());
                    while (oaInstTerm *InstTerm_p_lock = InstTermIter_p_lock.getNext())
                    {
                      oaNet *Net_p_lock = InstTerm_p_lock->getNet(true);
                      //oaString netname;
                      //Net_p_lock->getName(ns,netname);
                      //cout<<netname<<" "<<Net_p_lock->getSigType()<<endl;
                      oaIter<oaInstTerm> ITIter(Net_p_lock->getInstTerms());
                      if (Net_p_lock->getSigType()==0)
                      {                      
                        while (oaInstTerm *IT = ITIter.getNext())
                         {
                           oaInst *I = IT->getInst();
                          
                           I->setPlacementStatus(PS);
                         }
                      }
                    }
                    oaIter<oaInstTerm> InstTermIter_q_lock(Inst_Array[max_decrease_q]->getInstTerms());
                    while (oaInstTerm *InstTerm_q_lock = InstTermIter_q_lock.getNext())
                    {
                      oaNet *Net_q_lock = InstTerm_q_lock->getNet(true);
                      //oaString netname;
                      //Net_q_lock->getName(ns,netname);
                      //cout<<netname<<" "<<Net_q_lock->getSigType()<<endl;
                      if (Net_q_lock->getSigType()==0)
                      {
                        oaIter<oaInstTerm> ITIter(Net_q_lock->getInstTerms());
                      
                        while (oaInstTerm *IT = ITIter.getNext())
                         {
                           oaInst *I = IT->getInst();
                           I->setPlacementStatus(PS);
                         }
                       }
                    }
                    
                    
                 } //end of if(max_decrease>0) 
                    
           }// end of times

        } 
        else 
        {
        cout << "There is no block in this design" << endl;
        } 
        
          int HPWL_Increment=0;
          //HPWL_Increment=HPWL_Calc(block);
         HPWL_Increment=HPWL_Original-sum_decrease;
        // cout<<"HPWL_after:"<<HPWL_Increment<<endl;  
         result[0]=HPWL_Increment;result[1]=swap_times;
         return result;
         
}
// ****************************************************************************
// main()
//
// This is the top level function that opens the design, prints library, cell,
// and view names, creates nets, and iterates the design to print the net 
// names.
// ****************************************************************************
int
main(int    argc,
     char   *argv[])
{
    try {
        // Initialize OA with data model 3, since incremental technology
        // databases are supported by this application.
        oaDesignInit(oacAPIMajorRevNumber, oacAPIMinorRevNumber, 3);

        oaString                libPath("./DesignLib");
        oaString                library("DesignLib");
	oaViewType      	*viewType = oaViewType::get(oacMaskLayout);
        oaString        	cell("s1196_bench");
       	oaString        	view("layout"); 
	oaScalarName            libName(ns,
                                        library);
        oaScalarName            cellName(ns,
                                         cell);
        oaScalarName            viewName(ns,
                                         view);
	oaScalarName    	libraryName(ns,library);
        // Setup an instance of the oaTech conflict observer.
        opnTechConflictObserver myTechConflictObserver(1);

        // Setup an instance of the oaLibDefList observer.
        opnLibDefListObserver   myLibDefListObserver(1);

        // Read in the lib.defs file.
	oaLib *lib = oaLib::find(libraryName);

        if (!lib) {
            if (oaLib::exists(libPath)) {
                // Library does exist at this path but was not in lib.defs
                lib = oaLib::open(libraryName, libPath);
            } else {
            char *DMSystem=getenv("DMSystem");
            if(DMSystem){
                    lib = oaLib::create(libraryName, libPath, oacSharedLibMode, DMSystem);
                } else {
                    lib = oaLib::create(libraryName, libPath);
                }
            }
            if (lib) {
                // We need to update the user's lib.def file since we either
                // found or created the library without a lib.defs reference.
                updateLibDefsFile(libraryName, libPath);
            } else {
                // Print error mesage 
                cerr << "ERROR : Unable to create " << libPath << "/";
                cerr << library << endl;
                return(1);
            }
        }
	// Create the design with the specified viewType,
        // Opening it for a 'write' operation.
        cout << "The design is created and opened in 'write' mode." << endl;

        oaDesign    *design = oaDesign::open(libraryName, cellName, viewName,
                                             viewType, 'r');

        // The library, cell, and view names are printed.
        printDesignNames(design);
		  printNets(design);

	// Get the TopBlock for this design.
        oaBlock *block = design->getTopBlock();
	
	// If no TopBlock exist yet then create one.
        if (!block) {
            block = oaBlock::create(design);
        }

        //EE 201A Lab 3 Problem 1 starts here
        cout << endl << "----- LONGJIA NIU: Problem 1 -----" << endl;

        int HPWL_Original=0;
        HPWL_Original=HPWL_Calc(block);
        
        //EE 201A Lab 3 Problem 2 starts here
        cout << endl << "----- LONGJIA NIU: Problem 2 -----" << endl;

        int *HPWL_result=HPWL_Calc_Increment_LockNone(block,HPWL_Original);
    ////////////////////////////////////////////////////////////////////
        //Output answers:
        cout << "Problem 1 -- Total wirelength of original design: " << HPWL_Original << endl;
        cout << "Problem 2 -- Total wirelength AFTER my incremental placement algorithm:  " << HPWL_result[0] << endl;
        cout << "Problem 2 -- Total number of swaps used:  " << HPWL_result[1] << endl;

        // The design is closed.   
        design->close();

        // The library is closed.   
        lib->close();

    } catch (oaCompatibilityError &ex) {
        handleFBCError(ex);
        exit(1); 

    } catch (oaException &excp) {
        cout << "ERROR: " << excp.getMsg() << endl;
        exit(1);
    }

    return 0;
}


