grep "Path 1:" encounter/s1494_final_setup.tarpt
grep "Path 1:" encounter/s1494_final_hold.tarpt
grep "Total area" encounter/summary.rpt
cat encounter/s1494.geom.rpt
