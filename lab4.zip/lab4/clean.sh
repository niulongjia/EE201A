#!/bin/bash

rm *.log*
rm *.cmd*
rm .routing_guide.rgf
rm .FECheckNetlistTempFile
rm CTS_RP_MOVE.txt
rm checknetlist.rpt
rm checkPlacement.rpt
rm streamOut.map
rm s1494_bench.cts_trace
rm -rf timingReports
rm -rf output
mkdir output
