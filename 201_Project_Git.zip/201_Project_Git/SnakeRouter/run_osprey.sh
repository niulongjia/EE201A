#!/bin/bash
#
# Author: Mark Gottscho
# Email: mgottscho@ucla.edu
#
# Tests SnakeRouter with an Osprey program.
#
# Example usage:
#
# ./run_osprey.sh AND2_X1 min minimum

#CELL=$1
#DESIGNRULES=$2
#DESIGNRULES_FULL=$3

#./Osprey $CELL $CELL\_routed_$DESIGNRULES\rule testcases/$CELL.netlist testcases/$DESIGNRULES_FULL.designrules

# "...AND2_X1..."
./Osprey AND2_X1 AND2_X1_routed_minrule testcases/AND2_X1.netlist testcases/minimum.designrules #> logs/AND2_X1_routed_minrule.log
# "...AND2_X4..."
./Osprey AND2_X4 AND2_X4_routed_minrule testcases/AND2_X4.netlist testcases/minimum.designrules #> logs/AND2_X4_routed_minrule.log
# "...DFF_X2..."
./Osprey DFF_X2 DFF_X2_routed_minrule testcases/DFF_X2.netlist testcases/minimum.designrules #> logs/DFF_X2_routed_minrule.log
# "...INV_X1..."
./Osprey INV_X1 INV_X1_routed_minrule testcases/INV_X1.netlist testcases/minimum.designrules #> logs/INV_X1_routed_minrule.log
# "...INV_X32..."
./Osprey INV_X32 INV_X32_routed_minrule testcases/INV_X32.netlist testcases/minimum.designrules #> logs/INV_X32_routed_minrule.log
# "...LOGIC0_X1..."
./Osprey LOGIC0_X1 LOGIC0_X1_routed_minrule testcases/LOGIC0_X1.netlist testcases/minimum.designrules #> logs/LOGIC0_X1_routed_minrule.log
# "...OAI21_X1..."
./Osprey OAI21_X1 OAI21_X1_routed_minrule testcases/OAI21_X1.netlist testcases/minimum.designrules #> logs/OAI21_X1_routed_minrule.log



# "...AND2_X1..."
./Osprey AND2_X1 AND2_X1_routed_interrule testcases/AND2_X1.netlist testcases/inter.designrules #> logs/AND2_X1_routed_minrule.log
# "...AND2_X4..."
./Osprey AND2_X4 AND2_X4_routed_interrule testcases/AND2_X4.netlist testcases/inter.designrules #> logs/AND2_X4_routed_minrule.log
# "...DFF_X2..."
./Osprey DFF_X2 DFF_X2_routed_interrule testcases/DFF_X2.netlist testcases/inter.designrules #> logs/DFF_X2_routed_minrule.log
# "...INV_X1..."
./Osprey INV_X1 INV_X1_routed_interrule testcases/INV_X1.netlist testcases/inter.designrules #> logs/INV_X1_routed_minrule.log
# "...INV_X32..."
./Osprey INV_X32 INV_X32_routed_interrule testcases/INV_X32.netlist testcases/inter.designrules #> logs/INV_X32_routed_minrule.log
# "...LOGIC0_X1..."
./Osprey LOGIC0_X1 LOGIC0_X1_routed_interrule testcases/LOGIC0_X1.netlist testcases/inter.designrules #> logs/LOGIC0_X1_routed_minrule.log
# "...OAI21_X1..."
./Osprey OAI21_X1 OAI21_X1_routed_interrule testcases/OAI21_X1.netlist testcases/inter.designrules #> logs/OAI21_X1_routed_minrule.log


# "...AND2_X1..."
./Osprey AND2_X1 AND2_X1_routed_randrule testcases/AND2_X1.netlist testcases/random.designrules #> logs/AND2_X1_routed_minrule.log
# "...AND2_X4..."
./Osprey AND2_X4 AND2_X4_routed_randrule testcases/AND2_X4.netlist testcases/random.designrules #> logs/AND2_X4_routed_minrule.log
# "...DFF_X2..."
./Osprey DFF_X2 DFF_X2_routed_randrule testcases/DFF_X2.netlist testcases/random.designrules #> logs/DFF_X2_routed_minrule.log
# "...INV_X1..."
./Osprey INV_X1 INV_X1_routed_randrule testcases/INV_X1.netlist testcases/random.designrules #> logs/INV_X1_routed_minrule.log
# "...INV_X32..."
./Osprey INV_X32 INV_X32_routed_randrule testcases/INV_X32.netlist testcases/random.designrules #> logs/INV_X32_routed_minrule.log
# "...LOGIC0_X1..."
./Osprey LOGIC0_X1 LOGIC0_X1_routed_randrule testcases/LOGIC0_X1.netlist testcases/random.designrules #> logs/LOGIC0_X1_routed_minrule.log
# "...OAI21_X1..."
./Osprey OAI21_X1 OAI21_X1_routed_randrule testcases/OAI21_X1.netlist testcases/random.designrules #> logs/OAI21_X1_routed_minrule.log


# "...AND2_X1..."
./Osprey AND2_X1 AND2_X1_routed_maxrule testcases/AND2_X1.netlist testcases/maximum.designrules #> logs/AND2_X1_routed_minrule.log
# "...AND2_X4..."
./Osprey AND2_X4 AND2_X4_routed_maxrule testcases/AND2_X4.netlist testcases/maximum.designrules #> logs/AND2_X4_routed_minrule.log
# "...DFF_X2..."
./Osprey DFF_X2 DFF_X2_routed_maxrule testcases/DFF_X2.netlist testcases/maximum.designrules #> logs/DFF_X2_routed_minrule.log
# "...INV_X1..."
./Osprey INV_X1 INV_X1_routed_maxrule testcases/INV_X1.netlist testcases/maximum.designrules #> logs/INV_X1_routed_minrule.log
# "...INV_X32..."
./Osprey INV_X32 INV_X32_routed_maxrule testcases/INV_X32.netlist testcases/maximum.designrules #> logs/INV_X32_routed_minrule.log
# "...LOGIC0_X1..."
./Osprey LOGIC0_X1 LOGIC0_X1_routed_maxrule testcases/LOGIC0_X1.netlist testcases/maximum.designrules #> logs/LOGIC0_X1_routed_minrule.log
# "...OAI21_X1..."
./Osprey OAI21_X1 OAI21_X1_routed_maxrule testcases/OAI21_X1.netlist testcases/maximum.designrules #> logs/OAI21_X1_routed_minrule.log