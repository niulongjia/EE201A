#!/bin/bash
#
# This script extracts the final output of DRC.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr
# Test
grep -H "TOTAL DRC Results Generated" output/drc/*.summary
