#!/bin/bash
#
# This script exports a single cell from an OA database to a GDS file.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

ARGC=$# # Get the number of arguments excluding arg0 (the script itself). Check for help message condition.
if [[ "$ARGC" != 4 ]]; then # Bad number of arguments
    echo "Usage: oa2gds.sh <OA_DATABASE_DIR> <LAYER_FILENAME> <CELL_NAME> <OUTPUT_GDS_FILENAME>"
    echo "This script must be run using the Bash shell."
    exit
fi

OA_DATABASE_DIR=$1
LAYER_FILENAME=$2
CELL_NAME=$3
OUTPUT_GDS_FILENAME=$4
oa2strm -lib $OA_DATABASE_DIR -cell $CELL_NAME -gds $OUTPUT_GDS_FILENAME -layerMap "$LAYER_FILENAME" -pathToPolygon -rectAsBoundary 
