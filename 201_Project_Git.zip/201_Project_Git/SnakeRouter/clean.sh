#!/bin/bash
#
# This script cleans up the working directory. Use with care!
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

rm -rf DesignLib/
rm -rf logs/
rm -rf output/
rm -rf drc/
rm -rf lvs/
rm -rf build/
rm -rf dist/
rm -rf unidirectionalityCheck/
rm -rf svdb/
rm cds.lib
rm *.log
rm *.automap
rm .dep.inc
rm *.calibre.db
rm *.drc.results
rm *.drc.summary
rm lib.defs
rm .sconsign.dblite
