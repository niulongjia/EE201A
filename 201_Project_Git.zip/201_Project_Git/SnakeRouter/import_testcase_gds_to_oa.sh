#!/bin/bash
#
# This script imports specific GDS files to an OA database.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

ARGC=$# # Get the number of arguments excluding arg0 (the script itself). Check for help message condition.
if [[ "$ARGC" != 1 ]]; then # Bad number of arguments
    echo "Usage: import_testcase_gds_to_oa.sh <PATH_CONTAINING_GDS_FILES>"
    echo "This script must be run using the Bash shell."
    exit
fi

PATH_CONTAINING_GDS_FILES=$1
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/AND2_X1.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/AND2_X4.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/DFF_X2.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/INV_X1.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/INV_X32.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/LOGIC0_X1.gds
./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/OAI21_X1.gds
#./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/HIDDEN1.gds
#./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/HIDDEN2.gds
#./gds2oa.sh DesignLib layer.map $PATH_CONTAINING_GDS_FILES/HIDDEN3.gds
