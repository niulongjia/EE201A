#!/bin/bash
#
# This script extracts the final output of LVS.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

grep -r "LVS completed. CORRECT." logs/lvs.log
grep -r "LVS completed. INCORRECT." logs/lvs.log
