#!/bin/bash
#
# This script runs DRC.
#
# Author: Shaodi Wang, Liangzhen Lai, and Mark Gottscho
# Email: shaodiw@ucla.edu, liangzhen@ucla.edu, mgottscho@ucla.edu
# Copyright (C) 2013 Shaodi Wang and Liangzhen Lai
# Copyright (C) 2015 Mark Gottscho

sed -e 's/CELLNAME/INV_X1/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_INV_X1_minrule
calibre -drc -hier rules_INV_X1_minrule
sed -e 's/RULES/interrule/g' temp > rules_INV_X1_interrule
calibre -drc -hier rules_INV_X1_interrule
sed -e 's/RULES/randrule/g' temp > rules_INV_X1_randrule
calibre -drc -hier rules_INV_X1_randrule
sed -e 's/RULES/maxrule/g' temp > rules_INV_X1_maxrule
calibre -drc -hier rules_INV_X1_maxrule


sed -e 's/CELLNAME/INV_X32/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_INV_X32_minrule
calibre -drc -hier rules_INV_X32_minrule
sed -e 's/RULES/interrule/g' temp > rules_INV_X32_interrule
calibre -drc -hier rules_INV_X32_interrule
sed -e 's/RULES/randrule/g' temp > rules_INV_X32_randrule
calibre -drc -hier rules_INV_X32_randrule
sed -e 's/RULES/maxrule/g' temp > rules_INV_X32_maxrule
calibre -drc -hier rules_INV_X32_maxrule

sed -e 's/CELLNAME/AND2_X1/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_AND2_X1_minrule
calibre -drc -hier rules_AND2_X1_minrule
sed -e 's/RULES/interrule/g' temp > rules_AND2_X1_interrule
calibre -drc -hier rules_AND2_X1_interrule
sed -e 's/RULES/randrule/g' temp > rules_AND2_X1_randrule
calibre -drc -hier rules_AND2_X1_randrule
sed -e 's/RULES/maxrule/g' temp > rules_AND2_X1_maxrule
calibre -drc -hier rules_AND2_X1_maxrule


sed -e 's/CELLNAME/AND2_X4/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_AND2_X4_minrule
calibre -drc -hier rules_AND2_X4_minrule
sed -e 's/RULES/interrule/g' temp > rules_AND2_X4_interrule
calibre -drc -hier rules_AND2_X4_interrule
sed -e 's/RULES/randrule/g' temp > rules_AND2_X4_randrule
calibre -drc -hier rules_AND2_X4_randrule
sed -e 's/RULES/maxrule/g' temp > rules_AND2_X4_maxrule
calibre -drc -hier rules_AND2_X4_maxrule

sed -e 's/CELLNAME/LOGIC0_X1/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_LOGIC0_X1_minrule
calibre -drc -hier rules_LOGIC0_X1_minrule
sed -e 's/RULES/interrule/g' temp > rules_LOGIC0_X1_interrule
calibre -drc -hier rules_LOGIC0_X1_interrule
sed -e 's/RULES/randrule/g' temp > rules_LOGIC0_X1_randrule
calibre -drc -hier rules_LOGIC0_X1_randrule
sed -e 's/RULES/maxrule/g' temp > rules_LOGIC0_X1_maxrule
calibre -drc -hier rules_LOGIC0_X1_maxrule

sed -e 's/CELLNAME/DFF_X2/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_DFF_X2_minrule
calibre -drc -hier rules_DFF_X2_minrule
sed -e 's/RULES/interrule/g' temp > rules_DFF_X2_interrule
calibre -drc -hier rules_DFF_X2_interrule
sed -e 's/RULES/randrule/g' temp > rules_DFF_X2_randrule
calibre -drc -hier rules_DFF_X2_randrule
sed -e 's/RULES/maxrule/g' temp > rules_DFF_X2_maxrule
calibre -drc -hier rules_DFF_X2_maxrule

sed -e 's/CELLNAME/OAI21_X1/g' DRC_CELL.rul > temp
sed -e 's/RULES/minrule/g' temp > rules_OAI21_X1_minrule
calibre -drc -hier rules_OAI21_X1_minrule
sed -e 's/RULES/interrule/g' temp > rules_OAI21_X1_interrule
calibre -drc -hier rules_OAI21_X1_interrule
sed -e 's/RULES/randrule/g' temp > rules_OAI21_X1_randrule
calibre -drc -hier rules_OAI21_X1_randrule
sed -e 's/RULES/maxrule/g' temp > rules_OAI21_X1_maxrule
calibre -drc -hier rules_OAI21_X1_maxrule

#sed -e 's/CELLNAME/HIDDEN1/g' DRC_CELL.rul > temp
#sed -e 's/RULES/minrule/g' temp > rules_HIDDEN1_minrule
#calibre -drc -hier rules_HIDDEN1_minrule
#sed -e 's/RULES/interrule/g' temp > rules_HIDDEN1_interrule
#calibre -drc -hier rules_HIDDEN1_interrule
#sed -e 's/RULES/randrule/g' temp > rules_HIDDEN1_randrule
#calibre -drc -hier rules_HIDDEN1_randrule
#sed -e 's/RULES/maxrule/g' temp > rules_HIDDEN1_maxrule
#calibre -drc -hier rules_HIDDEN1_maxrule

#sed -e 's/CELLNAME/HIDDEN2/g' DRC_CELL.rul > temp
#sed -e 's/RULES/minrule/g' temp > rules_HIDDEN2_minrule
#calibre -drc -hier rules_HIDDEN2_minrule
#sed -e 's/RULES/interrule/g' temp > rules_HIDDEN2_interrule
#calibre -drc -hier rules_HIDDEN2_interrule
#sed -e 's/RULES/randrule/g' temp > rules_HIDDEN2_randrule
#calibre -drc -hier rules_HIDDEN2_randrule
#sed -e 's/RULES/maxrule/g' temp > rules_HIDDEN2_maxrule
#calibre -drc -hier rules_HIDDEN2_maxrule

#sed -e 's/CELLNAME/HIDDEN3/g' DRC_CELL.rul > temp
#sed -e 's/RULES/minrule/g' temp > rules_HIDDEN3_minrule
#calibre -drc -hier rules_HIDDEN3_minrule
#sed -e 's/RULES/interrule/g' temp > rules_HIDDEN3_interrule
#calibre -drc -hier rules_HIDDEN3_interrule
#sed -e 's/RULES/randrule/g' temp > rules_HIDDEN3_randrule
#calibre -drc -hier rules_HIDDEN3_randrule
#sed -e 's/RULES/maxrule/g' temp > rules_HIDDEN3_maxrule
#calibre -drc -hier rules_HIDDEN3_maxrule

rm temp
