#!/bin/bash
#
# This script runs LVS.
#
# Author: Shaodi Wang, Liangzhen Lai, and Mark Gottscho
# Email: shaodiw@ucla.edu, liangzhen@ucla.edu, mgottscho@ucla.edu
# Copyright (C) 2013 Shaodi Wang and Liangzhen Lai
# Copyright (C) 2015 Mark Gottscho

sed -e 's/CELLNAME/INV_X1/g' runset_CELL_minrule>runset_INV_X1_minrule
sed -e 's/CELLNAME/INV_X1/g' runset_CELL_interrule>runset_INV_X1_interrule
sed -e 's/CELLNAME/INV_X1/g' runset_CELL_randrule>runset_INV_X1_randrule
sed -e 's/CELLNAME/INV_X1/g' runset_CELL_maxrule>runset_INV_X1_maxrule
calibre -gui -lvs -runset runset_INV_X1_minrule -batch
calibre -gui -lvs -runset runset_INV_X1_interrule -batch
calibre -gui -lvs -runset runset_INV_X1_randrule -batch
calibre -gui -lvs -runset runset_INV_X1_maxrule -batch

sed -e 's/CELLNAME/INV_X32/g' runset_CELL_minrule>runset_INV_X32_minrule
sed -e 's/CELLNAME/INV_X32/g' runset_CELL_interrule>runset_INV_X32_interrule
sed -e 's/CELLNAME/INV_X32/g' runset_CELL_randrule>runset_INV_X32_randrule
sed -e 's/CELLNAME/INV_X32/g' runset_CELL_maxrule>runset_INV_X32_maxrule
calibre -gui -lvs -runset runset_INV_X32_minrule -batch
calibre -gui -lvs -runset runset_INV_X32_interrule -batch
calibre -gui -lvs -runset runset_INV_X32_randrule -batch
calibre -gui -lvs -runset runset_INV_X32_maxrule -batch

sed -e 's/CELLNAME/AND2_X1/g' runset_CELL_minrule>runset_AND2_X1_minrule
sed -e 's/CELLNAME/AND2_X1/g' runset_CELL_interrule>runset_AND2_X1_interrule
sed -e 's/CELLNAME/AND2_X1/g' runset_CELL_randrule>runset_AND2_X1_randrule
sed -e 's/CELLNAME/AND2_X1/g' runset_CELL_maxrule>runset_AND2_X1_maxrule
calibre -gui -lvs -runset runset_AND2_X1_minrule -batch
calibre -gui -lvs -runset runset_AND2_X1_interrule -batch
calibre -gui -lvs -runset runset_AND2_X1_randrule -batch
calibre -gui -lvs -runset runset_AND2_X1_maxrule -batch

sed -e 's/CELLNAME/AND2_X4/g' runset_CELL_minrule>runset_AND2_X4_minrule
sed -e 's/CELLNAME/AND2_X4/g' runset_CELL_interrule>runset_AND2_X4_interrule
sed -e 's/CELLNAME/AND2_X4/g' runset_CELL_randrule>runset_AND2_X4_randrule
sed -e 's/CELLNAME/AND2_X4/g' runset_CELL_maxrule>runset_AND2_X4_maxrule
calibre -gui -lvs -runset runset_AND2_X4_minrule -batch
calibre -gui -lvs -runset runset_AND2_X4_interrule -batch
calibre -gui -lvs -runset runset_AND2_X4_randrule -batch
calibre -gui -lvs -runset runset_AND2_X4_maxrule -batch

sed -e 's/CELLNAME/LOGIC0_X1/g' runset_CELL_minrule>runset_LOGIC0_X1_minrule
sed -e 's/CELLNAME/LOGIC0_X1/g' runset_CELL_interrule>runset_LOGIC0_X1_interrule
sed -e 's/CELLNAME/LOGIC0_X1/g' runset_CELL_randrule>runset_LOGIC0_X1_randrule
sed -e 's/CELLNAME/LOGIC0_X1/g' runset_CELL_maxrule>runset_LOGIC0_X1_maxrule
calibre -gui -lvs -runset runset_LOGIC0_X1_minrule -batch
calibre -gui -lvs -runset runset_LOGIC0_X1_interrule -batch
calibre -gui -lvs -runset runset_LOGIC0_X1_randrule -batch
calibre -gui -lvs -runset runset_LOGIC0_X1_maxrule -batch

sed -e 's/CELLNAME/DFF_X2/g' runset_CELL_minrule>runset_DFF_X2_minrule
sed -e 's/CELLNAME/DFF_X2/g' runset_CELL_interrule>runset_DFF_X2_interrule
sed -e 's/CELLNAME/DFF_X2/g' runset_CELL_randrule>runset_DFF_X2_randrule
sed -e 's/CELLNAME/DFF_X2/g' runset_CELL_maxrule>runset_DFF_X2_maxrule
calibre -gui -lvs -runset runset_DFF_X2_minrule -batch
calibre -gui -lvs -runset runset_DFF_X2_interrule -batch
calibre -gui -lvs -runset runset_DFF_X2_randrule -batch
calibre -gui -lvs -runset runset_DFF_X2_maxrule -batch

sed -e 's/CELLNAME/OAI21_X1/g' runset_CELL_minrule>runset_OAI21_X1_minrule
sed -e 's/CELLNAME/OAI21_X1/g' runset_CELL_interrule>runset_OAI21_X1_interrule
sed -e 's/CELLNAME/OAI21_X1/g' runset_CELL_randrule>runset_OAI21_X1_randrule
sed -e 's/CELLNAME/OAI21_X1/g' runset_CELL_maxrule>runset_OAI21_X1_maxrule
calibre -gui -lvs -runset runset_OAI21_X1_minrule -batch
calibre -gui -lvs -runset runset_OAI21_X1_interrule -batch
calibre -gui -lvs -runset runset_OAI21_X1_randrule -batch
calibre -gui -lvs -runset runset_OAI21_X1_maxrule -batch
#
#sed -e 's/CELLNAME/HIDDEN1/g' runset_CELL_minrule>runset_OAI21_X1_minrule
#sed -e 's/CELLNAME/HIDDEN1/g' runset_CELL_interrule>runset_OAI21_X1_interrule
#sed -e 's/CELLNAME/HIDDEN1/g' runset_CELL_randrule>runset_OAI21_X1_randrule
#sed -e 's/CELLNAME/HIDDEN1/g' runset_CELL_maxrule>runset_OAI21_X1_maxrule
#calibre -gui -lvs -runset runset_HIDDEN1_X1_minrule -batch
#calibre -gui -lvs -runset runset_HIDDEN1_X1_interrule -batch
#calibre -gui -lvs -runset runset_HIDDEN1_X1_randrule -batch
#calibre -gui -lvs -runset runset_HIDDEN1_X1_maxrule -batch
#
#sed -e 's/CELLNAME/HIDDEN2/g' runset_CELL_minrule>runset_OAI21_X1_minrule
#sed -e 's/CELLNAME/HIDDEN2/g' runset_CELL_interrule>runset_OAI21_X1_interrule
#sed -e 's/CELLNAME/HIDDEN2/g' runset_CELL_randrule>runset_OAI21_X1_randrule
#sed -e 's/CELLNAME/HIDDEN2/g' runset_CELL_maxrule>runset_OAI21_X1_maxrule
#calibre -gui -lvs -runset runset_HIDDEN2_X1_minrule -batch
#calibre -gui -lvs -runset runset_HIDDEN2_X1_interrule -batch
#calibre -gui -lvs -runset runset_HIDDEN2_X1_randrule -batch
#calibre -gui -lvs -runset runset_HIDDEN2_X1_maxrule -batch
#
#sed -e 's/CELLNAME/HIDDEN3/g' runset_CELL_minrule>runset_OAI21_X1_minrule
#sed -e 's/CELLNAME/HIDDEN3/g' runset_CELL_interrule>runset_OAI21_X1_interrule
#sed -e 's/CELLNAME/HIDDEN3/g' runset_CELL_randrule>runset_OAI21_X1_randrule
#sed -e 's/CELLNAME/HIDDEN3/g' runset_CELL_maxrule>runset_OAI21_X1_maxrule
#calibre -gui -lvs -runset runset_HIDDEN3_X1_minrule -batch
#calibre -gui -lvs -runset runset_HIDDEN3_X1_interrule -batch
#calibre -gui -lvs -runset runset_HIDDEN3_X1_randrule -batch
#calibre -gui -lvs -runset runset_HIDDEN3_X1_maxrule -batch

