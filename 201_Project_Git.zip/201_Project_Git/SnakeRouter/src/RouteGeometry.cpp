/* Authors: Mark Gottscho and Yasmine Badr
 * Email: mgottscho@ucla.edu, ybadr@ucla.edu
 * Copyright (C) 2013 Mark Gottscho and Yasmine Badr
 */

#include <cmath>
#include "RouteGeometry.h"
#include "Definitions.h"
#include "ProjectDesignRules.h"
#include <iostream>
using namespace std;

RouteGeometry::RouteGeometry()
{
}

RouteGeometry::~RouteGeometry()
{
}


void RouteGeometry::METAL_LAYERS_INFO_Initial(ProjectDesignRules dr, METAL_LAYER_INFO *METAL_LAYERS_INFO)
{
   switch(dr.getMetal1Direction())
   {
    case 'V': METAL_LAYERS_INFO[0].direction=VER;break;
    case 'H': METAL_LAYERS_INFO[0].direction=HOR;break;
    case 'B': METAL_LAYERS_INFO[0].direction=BI;break;
   }
   switch(dr.getMetal2Direction())
   {
    case 'V': METAL_LAYERS_INFO[1].direction=VER;break;
    case 'H': METAL_LAYERS_INFO[1].direction=HOR;break;
    case 'B': METAL_LAYERS_INFO[1].direction=BI;break;
   }
   switch(dr.getMetal3Direction())
   {
    case 'V': METAL_LAYERS_INFO[2].direction=VER;break;
    case 'H': METAL_LAYERS_INFO[2].direction=HOR;break;
    case 'B': METAL_LAYERS_INFO[2].direction=BI;break;
   }

}

void RouteGeometry::mazeToGeometry_specialCase(oaDesign* design,    
                        int topBound_V,int topBound_H,
                        int bottomBound_V,int bottomBound_H,
                        int leftBound_V,int leftBound_H,
                        int rightBound_V,int rightBound_H)
{
           int layer=0;
           oaBlock* topBlock = design->getTopBlock();
           oaPurposeNum purpNum = 1; //LPPHeader->getPurposeNum();
           oaLayerNum layNum=METAL_LAYERS_INFO[layer].layerNum;
           
           oaRect* newSeg_V = oaRect::create(topBlock, layNum, purpNum,
								      oaBox(leftBound_V, bottomBound_V, rightBound_V, topBound_V));

						          if (newSeg_V == NULL)
							        cerr << "newSeg_V is NULL!" << endl;
   
           oaRect* newSeg_H = oaRect::create(topBlock, layNum, purpNum,
								      oaBox(leftBound_H, bottomBound_H, rightBound_H, topBound_H));

						          if (newSeg_H == NULL)
							        cerr << "newSeg_H is NULL!" << endl;
        
}
//Weiche
void RouteGeometry::mazeToGeometry(Grid* grid, oaDesign* design,
        ProjectDesignRules dr)
{

     oaNativeNS	ns;
    //Now, each continuous horizontal route will be created as a continuous path
    //segment
    //a jump from m1 to m2 should create a via

    oaBlock* topBlock = design->getTopBlock();
    //get dimensions of grid
    unsigned int nLayers, nHorizTiles, nVerticTiles;

    grid->getDims(&nHorizTiles, &nVerticTiles, &nLayers);
    
    METAL_LAYERS_INFO_Initial(dr, METAL_LAYERS_INFO);
    
   // cout<<"METAL_LAYERS_INFO[0].direction:"<<METAL_LAYERS_INFO[0].direction<<endl;
   // cout<<"METAL_LAYERS_INFO[1].direction:"<<METAL_LAYERS_INFO[1].direction<<endl;
   // cout<<"METAL_LAYERS_INFO[2].direction:"<<METAL_LAYERS_INFO[2].direction<<endl;
    
    for (int layer = 0; layer < nLayers; layer++)
    {
    	//cout << "layer : " << nLayers << "current layer :" << layer << endl;
    	//bool bidirection =false;
        oaLayerNum layNum = METAL_LAYERS_INFO[layer].layerNum; //LPPHeader->getLayerNum();
        oaPurposeNum purpNum = 1; //LPPHeader->getPurposeNum();
       
        //first dimension is the dimension perpendicular to routing layer direction
        //and second dimension is the dimension along routing layer direction
        int nTilesFirstDim, nTilesSecondDim;

        METAL_LAYER_INFO layerInfo = METAL_LAYERS_INFO[layer];
        int extFromCenterX, extFromCenterY;
        int wireWidth = dr.getMetalWidthRule();
        unsigned int w, h;
        grid->getCellDims(&w, &h);
        if (layerInfo.direction == VER)
        {
            nTilesFirstDim = nHorizTiles;
            nTilesSecondDim = nVerticTiles;
           
        } else if (layerInfo.direction == HOR)
        {
            nTilesFirstDim = nVerticTiles;
            nTilesSecondDim = nHorizTiles;
        }
        else if (layerInfo.direction == BI)
        {
        //	cout << "Bidirection detected : layer:"<< layer << "   " << METAL_LAYERS_INFO[layer].layerNum <<endl;
        	nTilesFirstDim = nHorizTiles;
			    nTilesSecondDim = nVerticTiles;
        	//bidirection =true;
        }
      //  extFromCenterX = static_cast<int>(ceil(wireWidth / 2));
      //  extFromCenterY = static_cast<int>(ceil(wireWidth / 2));
        for (int firstDim = 0; firstDim < nTilesFirstDim; firstDim++)
        {
            //Now I want to get the longest possible segments from the 
            //second dimension
            int secDim = 0;
            oaInt4 currNetID=-1;
            
            oaUInt4 tmpm,tmpn,tmpk;
                

            while (secDim < nTilesSecondDim)
            {
                bool singlecell_secDim = false;
                bool singlecell_allDim = false;
                //create a path segment representing every few successive
                //tiles along the routing layer direction
            	//if (bidirection)
            		//cout << "Iterating Cell : m: " <<firstDim << " n:" << secDim << " layer: "<< layer <<endl;
                //1-Skip non-occupied cells till we get to first filled cell
                
               
               Cell* currCell;
                do{
                	if (layerInfo.direction == VER || layerInfo.direction == HOR) 
                		currCell = GetCell(grid, layerInfo, firstDim, secDim, layer);
                	else currCell = grid->at( firstDim, secDim, layer);
                    secDim++;
                }
                while (!(currCell->getStatus() == CellFilled || currCell->getStatus() == CellContact)
                      && secDim < nTilesSecondDim);
            	
                singlecell_secDim = false;
                singlecell_allDim = false;
                
                if (currCell->getStatus() == CellFilled|| currCell->getStatus() == CellContact)//check that we found filled cell
                    //and not that we went out of bounds
                {
                	//if (bidirection)
						      //cout << "First Cell : m: " <<firstDim << " n:" << secDim-1  << " layer: "<< layer <<endl;
                    oaInt4 left, bottom, right, top;
                        

                    //Now we have found the first filled cell==>Get its center             
                    //Found start point: get left and bottom of rectangle starting point
                    oaInt4 xCenter, yCenter;
                    currCell->getAbsolutePosition(&xCenter, &yCenter);
                                     
                    oaNet* currNet=NULL;
                     //create net
                    char netNameCharP[25];
                    snprintf(netNameCharP, sizeof (currCell->getNetID()), "%d", 
                             currCell->getNetID());

                    oaName netName(ns,netNameCharP);
                    currNet=oaNet::find(topBlock, netName);
                    if(!currNet)//if not already created
                         currNet=oaNet::create(topBlock, netName);
                   
                   
                        if (layer==0 && currCell->isSingleCell()==true )  
                          {
                        		//cout << "singlecell_secDim set to true!" <<endl;
                        		singlecell_allDim  = true;
    
                        	}   
               

                    if (layerInfo.direction == VER)
                    {

                        bottom = yCenter - ceil(double(dr.getFattenedWidthRule())/2);
                        left = xCenter - ceil(double(dr.getFattenedWidthRule())/2);
                        right = xCenter + ceil(double(dr.getFattenedWidthRule())/2); 
                    } 
                    else if (layerInfo.direction == HOR)
                    {

                        left = xCenter - ceil(double(dr.getFattenedWidthRule())/2);
                        top = yCenter + ceil(double(dr.getFattenedWidthRule())/2);
                        bottom = yCenter - ceil(double(dr.getFattenedWidthRule())/2); 
                          
                    } 
                    else if (layerInfo.direction == BI)
                    { 
                       
                          oaUInt4 m,n,k=0;
                          Cell* currCell_down;
                          currCell->getPosition(&m,&n,&k);
                          if (k>=1) currCell_down=grid->at(m,n,k-1);
                          CellStatus currCell_Status=currCell->getStatus();

                        bottom = yCenter - ceil(double(dr.getFattenedWidthRule())/2);
                        left = xCenter - ceil(double(dr.getFattenedWidthRule())/2);
                        right = xCenter + ceil(double(dr.getFattenedWidthRule())/2); 

                         
                          Cell* top_cell = grid->at(firstDim,secDim,layer);
                        	if (!(top_cell->getStatus() == CellFilled
                                    || top_cell->getStatus() == CellContact))
                        	{
                        		//cout << "singlecell_secDim set to true!" <<endl;
                        		singlecell_secDim  = true;
    
                        	}
                         

                    }
                    
                    Cell* firstCell=currCell;
                    
                    //if (layerInfo.direction==BI)
                   	//cout << "Vertical --- First Cell : m: " <<firstDim << "n:" << secDim-1 << "layer: "<< layer <<endl;
                    //Now go till the last filled cell
                    
                    do
                    {
                        currNetID=currCell->getNetID();//currCell starts at the first cell
                        int tempX, tempY;
                        currCell->getAbsolutePosition(&tempX,&tempY);
                        if(currCell->needsVia() ||currCell->needsVia2())
                        {
                            oaRect* via=createVia(currCell, dr,design);
                            if(currNet==NULL)
                                cerr<<"currNet is NULL"<<endl;
                            else via->addToNet(currNet);
                        }
                       
                        //if pin, create label
                        if (currCell->isPin())
                        {                         
                            //Create pin label
                            CreatePinTextLabel(currCell, design,dr);
                        }
                        if(secDim==nTilesSecondDim)
                        {
                        	break;
                        }
                        
                        if (layerInfo.direction == HOR)
                        {
                            
                            if ( firstDim>0 && firstDim<nTilesFirstDim-1 && secDim>0 && secDim<nTilesSecondDim-1 &&
                                  ((layer==0 && grid->at(secDim-1,firstDim,0)->needsVia()==1) ||
                                  (layer==1 && (grid->at(secDim-1,firstDim,1)->needsVia2()==1 ||  grid->at(secDim-1,firstDim,0)->needsVia()==1) )||
                                  (layer==2 && grid->at(secDim-1,firstDim,1)->needsVia2()==1)) ) 
                                  {
                                    // cout<<"------ HOR: "<<secDim-1<<" "<<firstDim<<"--------"<<endl;                
                                           
                                           oaInt4 viaXCenter;
                                           oaInt4 viaYCenter;
                                           currCell->getAbsolutePosition(&viaXCenter,&viaYCenter);

                                       	oaInt4 viaExtTop;
                        								oaInt4 viaExtBottom;
                                        oaInt4 viaExtLeft;
                                        oaInt4 viaExtRight;         	

                                        viaExtTop =  viaYCenter + ceil(double(dr.getFattenedWidthRule())/2);
                        								viaExtBottom =  viaYCenter - ceil(double(dr.getFattenedWidthRule())/2);
                                        viaExtLeft =  viaXCenter - ceil(double(dr.getFattenedWidthRule())/2);
                                        viaExtRight = viaXCenter + ceil(double(dr.getFattenedWidthRule())/2); 
                                               oaRect* newSeg = oaRect::create(topBlock, layNum, purpNum,
                          								      oaBox(viaExtLeft, viaExtBottom, viaExtRight, viaExtTop));

                          						          if (newSeg == NULL)
                          							        cerr << "newSeg is NULL!" << endl;
                          						           else      
                                                {
                             							        if (currNet == NULL)
                             								      cerr << "currNet is NULL after creation of newSeg" << endl;
                             							        else newSeg->addToNet(currNet);
                          						           }

                
                                  }
                        }
                        else // VER or BI
                        {
                          
                          //Deal with vias
                          if (  firstDim>0 && firstDim<nTilesFirstDim-1 && secDim>0 && secDim<nTilesSecondDim-1 &&
                               ((layer==0 && grid->at(firstDim,secDim-1,0)->needsVia()==1) ||
                               (layer==1 && (grid->at(firstDim,secDim-1,1)->needsVia2()==1 ||  grid->at(firstDim,secDim-1,0)->needsVia()==1) ) ||
                               (layer==2 && grid->at(firstDim,secDim-1,1)->needsVia2()==1)) ) 
                              {
                             // cout<<"------- VER or BI:"<<firstDim<<" "<<secDim-1<<"------"<<endl;
                                      
                                         oaInt4 viaXCenter;
                                         oaInt4 viaYCenter;
                                         currCell->getAbsolutePosition(&viaXCenter,&viaYCenter);
                                        
                                        oaInt4 viaExtTop;
                        								oaInt4 viaExtBottom;
                                        oaInt4 viaExtLeft;
                                        oaInt4 viaExtRight;         	

                                        viaExtTop =  viaYCenter + ceil(double(dr.getFattenedWidthRule())/2);
                        								viaExtBottom =  viaYCenter - ceil(double(dr.getFattenedWidthRule())/2);
                                        viaExtLeft =  viaXCenter - ceil(double(dr.getFattenedWidthRule())/2);
                                        viaExtRight = viaXCenter + ceil(double(dr.getFattenedWidthRule())/2); 
                                           
                                           oaRect* newSeg = oaRect::create(topBlock, layNum, purpNum,
                      								      oaBox(viaExtLeft, viaExtBottom, viaExtRight, viaExtTop));

                      						          if (newSeg == NULL)
                      							        cerr << "newSeg is NULL!" << endl;
                      						           else      
                                            {
                         							        if (currNet == NULL)
                         								      cerr << "currNet is NULL after creation of newSeg" << endl;
                         							        else newSeg->addToNet(currNet);
                      						           }

            
                              }
                        }
                    	if (layerInfo.direction == VER || layerInfo.direction == HOR)
                    		currCell = GetCell(grid, layerInfo, firstDim, secDim, layer);
                    	else currCell = grid->at( firstDim, secDim, layer);
                    	secDim++;
                    }
                    while ( (currCell->getStatus() == CellFilled
                           || currCell->getStatus() == CellContact)
                           && currCell->getNetID()==firstCell->getNetID());//same net)

                    //Now we have found the first empty cell after this segment
                    //endpoint should be the last cell
                    if(secDim==nTilesSecondDim)
                    {     
                        //currCell = GetCell(grid, layerInfo, firstDim, secDim-1, layer);
                    	if (layerInfo.direction == VER || layerInfo.direction == HOR)
                    		currCell = GetCell(grid, layerInfo, firstDim, secDim -1 , layer);
                    	else currCell = grid->at( firstDim, secDim-1, layer);
                    }
                    else //if we stopped because we found different net or because found an empty cell,
                        //then backup to the last cell
                    {
                        //currCell = GetCell(grid, layerInfo, firstDim, secDim - 2, layer);
                    	if (layerInfo.direction == VER || layerInfo.direction == HOR)
                    		currCell = GetCell(grid, layerInfo, firstDim, secDim-2, layer);
                    	else currCell = grid->at( firstDim, secDim-2, layer);
                    	secDim--;
                    }

                    currCell->getAbsolutePosition(&xCenter, &yCenter);
                    //cout << "xCenter: " << xCenter << " extFromCenterX: " << extFromCenterX << " " << endl;

                    if (layerInfo.direction == VER)
                       {

                           top = yCenter + ceil(double(dr.getFattenedWidthRule())/2);
                       } 
                    else if (layerInfo.direction == HOR)
                       {

                           right = xCenter + ceil(double(dr.getFattenedWidthRule())/2);
                       }
                    else if (layerInfo.direction == BI)
                       {
                          oaUInt4 m,n,k=0;
                          Cell* currCell_down;
                          currCell->getPosition(&m,&n,&k);
                          if (k>=1) currCell_down=grid->at(m,n,k-1);
                          CellStatus currCell_Status=currCell->getStatus();
                            

                           top = yCenter + ceil(double(dr.getFattenedWidthRule())/2);
                                                       


                       }
                       
                       // Check Single contact
                          if (singlecell_allDim == true)
                          {
  
                               oaInt4 IsolatedWid;
                               oaInt4 IsolatedExt;
                               
                               if (dr.getMinMetalAreaRule()>=(dr.getViaDimensionRule()+2*dr.getContactViaExtensionRule()) * (dr.getViaDimensionRule()+2*dr.getContactViaExtensionRule()))
                              {
                               // double temp = sqrt(dr.getMinMetalAreaRule());
                                IsolatedWid = ceil(sqrt(dr.getMinMetalAreaRule()));
                                IsolatedExt = ceil(double(IsolatedWid)/2);
                              }
                              
                              else
                              {
                                IsolatedWid = dr.getViaDimensionRule()+2*dr.getContactViaExtensionRule();
                                IsolatedExt = ceil(double(IsolatedWid)/2);
                              }
                             

     
                               oaInt4 left_Isolated = xCenter - IsolatedExt;
                               oaInt4 bottom_Isolated = yCenter - IsolatedExt;
                               oaInt4 right_Isolated = xCenter + IsolatedExt;
                               oaInt4 top_Isolated = yCenter + IsolatedExt;
                               
                               oaRect* newSeg = oaRect::create(topBlock, layNum, purpNum,
          								      oaBox(left_Isolated, bottom_Isolated, right_Isolated, top_Isolated));

          						          if (newSeg == NULL)
          							        cerr << "newSeg is NULL!" << endl;
          						           else      
                                {
             							        if (currNet == NULL)
             								      cerr << "currNet is NULL after creation of newSeg" << endl;
             							        else newSeg->addToNet(currNet);
          						           }                              
                               oaUInt4 m,n,k=0;
                               currCell->getPosition(&m,&n,&k);                               
                              // cout<<"-----------------------Single Cell BI---------------------"<<endl;
                              // cout<<m<<" "<<n<<" "<<k<<endl;
                              // cout<<"bottom: "<<bottom_Isolated<<" left: "<<left_Isolated<<"top: "<<top_Isolated<<" right: "<<right_Isolated<<endl;
                              //cout<<IsolatedWid<<endl;                              
                          }
                    //Create the wiring segment
                    //if (layerInfo.direction==BI)
                   	//cout << "Vertical --- Last Cell : m: " <<firstDim << "n:" << secDim-1 << "layer: "<< layer <<endl;
                         
                    if (singlecell_secDim==false && singlecell_allDim==false)
                         {
                         	  if (layerInfo.direction==BI)
                            {
                            oaUInt4 cell_w, cell_h = 0;
                            grid->getCellDims(&cell_w, &cell_h);
                  //cout << "oaBox  left_cell: " << left/cell_w << " bottom_cell: " << (bottom+850)/cell_w << " right_cell: " << right/cell_w << " top_cell:" << (top+850)/cell_w << endl;
                            }
                          
     						          oaRect* newSeg = oaRect::create(topBlock, layNum, purpNum,
     								      oaBox(left, bottom, right, top));

     						          if (newSeg == NULL)
     							        cerr << "newSeg is NULL!" << endl;
     						           else      
                           {
     							        if (currNet == NULL)
     								      cerr << "currNet is NULL after creation of newSeg" << endl;
     							        else newSeg->addToNet(currNet);
     						          }
                        }
                         
                }//end of if (currCell->getStatus() == CellFilled|| currCell->getStatus() == CellContact)
            }// end of while (secDim < nTilesSecondDim)
            //cout << "jumped out!" << endl;
            
        }// end of for (int firstDim = 0; firstDim < nTilesFirstDim; firstDim++)
        if (layerInfo.direction == BI)
        {
            layNum = METAL_LAYERS_INFO[layer].layerNum;
          //	cout << "--------------drawing horizontals for BI-----------------" << endl;
          // cout<<"layer:"<<layer<<" layNum:"<<layNum<<endl;
           
          	nTilesFirstDim = nVerticTiles;
  			    nTilesSecondDim = nHorizTiles;
  			    for (int firstDim = 0; firstDim < nTilesFirstDim; firstDim++)
  			    {
       				//Now I want to get the longest possible segments from the
       				//second dimension
       				int secDim = 0;
       				oaInt4 currNetID=-1;
  				    while (secDim < nTilesSecondDim)
  				    {
         					bool singlecell_secDim = false;
                  bool singlecell_allDim = false;
         					//create a path segment representing every few successive
         					//tiles along the routing layer direction
         //					if (bidirection)
         //						cout << "Iterating Cell : m: " <<firstDim << "n:" << secDim << "layer: "<< layer <<endl;
         					//1-Skip non-occupied cells till we get to first filled cell
         					Cell* currCell;
         					do{
                      currCell = grid->at( secDim, firstDim, layer);
         						secDim++;
         					}
         					while (!(currCell->getStatus() == CellFilled|| currCell->getStatus() == CellContact)
         						  && secDim < nTilesSecondDim);
         	            	singlecell_secDim = false;
                        singlecell_allDim = false;
                           
            					if (currCell->getStatus() == CellFilled|| currCell->getStatus() == CellContact)//check that we found filled cell
            						//and not that we went out of bounds
            					{
            						//if (layerInfo.direction==BI)
           							//cout << "Horizontal --- First Cell : m: " <<secDim-1 << " n:" << firstDim << " layer: "<< layer <<endl;
            						
                        oaInt4 left, bottom, right, top;
            						//Now we have found the first filled cell==>Get its center
            						//Found start point: get left and bottom of rectangle starting point
            						int xCenter, yCenter;
            						currCell->getAbsolutePosition(&xCenter, &yCenter);
            
            						oaNet* currNet=NULL;
            						 //create net
            						char netNameCharP[25];
            						snprintf(netNameCharP, sizeof (currCell->getNetID()), "%d",
            								 currCell->getNetID());
            
            						oaName netName(ns,netNameCharP);
            						currNet=oaNet::find(topBlock, netName);
            						if(!currNet)//if not already created
            							 currNet=oaNet::create(topBlock, netName);
                   
            
                                       oaUInt4 m,n,k=0;
                                       Cell* currCell_down;
                                      currCell->getPosition(&m,&n,&k);
                                      if (k>=1) currCell_down=grid->at(m,n,k-1);
                                      CellStatus currCell_Status=currCell->getStatus();
            
                              	 
            							     //top = yCenter + extFromCenterY;
                               //bottom = yCenter - extFromCenterY;
                                                         int n_scan=0;
                         
                     
                          Cell* left_cell = grid->at(secDim-2,firstDim,layer);
      	                  Cell* right_cell = grid->at(secDim,firstDim,layer);
                          Cell* top_cell = grid->at(secDim-1,firstDim+1,layer);
                          Cell* down_cell = grid->at(secDim-1,firstDim-1,layer);
                          Cell* above_cell = grid->at(secDim-1,firstDim,1);
                          

                          if (!(right_cell->getStatus() == CellFilled || right_cell->getStatus() == CellContact) )
      	                    	{
      	                    		//cout <<"singlecel set!!" <<endl;
      	                    		singlecell_secDim = true;
      
      	                    	}
                         // if (  (top_cell->getStatus() != CellFilled  && top_cell->getStatus() != CellContact) && 
                         //       (down_cell->getStatus() != CellFilled && down_cell->getStatus() != CellContact) &&
                         //       (left_cell->getStatus() != CellFilled && left_cell->getStatus() != CellContact) &&
                         //       (right_cell->getStatus() != CellFilled && right_cell->getStatus() != CellContact)  )
                         
                         // if (  (layer==0) &&
                         //       (top_cell->getStatus() == CellFree) && 
                         //       (down_cell->getStatus() == CellFree) &&
                         //       (left_cell->getStatus() == CellFree) &&
                         //       (right_cell->getStatus() == CellFree) &&
                         //       (currCell->needsVia() == 0)  ) 
                         if (layer==0 && currCell->isSingleCell() == true)
                        	{
                        		//cout << "singlecell_secDim set to true!" <<endl;
                        		singlecell_allDim  = true;
    
                        	}
                        /* 
                          if ( dr.getViaDimensionRule() + 2*dr.getContactViaExtensionRule() > dr.getMetalWidthRule() )
                             {
                              left = xCenter - (dr.getViaDimensionRule() / 2 + dr.getContactViaExtensionRule());
                              top = yCenter + (dr.getViaDimensionRule() / 2 + dr.getContactViaExtensionRule());
                              bottom = yCenter - (dr.getViaDimensionRule() / 2 + dr.getContactViaExtensionRule()); 
                             }
                             else
                             {
                              left = xCenter - extFromCenterX;
                              top = yCenter + extFromCenterY;
                              bottom = yCenter - extFromCenterY; 
                              }
                        */
                              left = xCenter - ceil(double(dr.getFattenedWidthRule())/2);
                              top = yCenter + ceil(double(dr.getFattenedWidthRule())/2);
                              bottom = yCenter - ceil(double(dr.getFattenedWidthRule())/2); 
                             //  if (singlecell_secDim==false)
                             //  {
            					       //  cout<<"--------Bidrectional Horizontal Segment StartCell BI--------"<<endl;
                             //  cout<<m<<" "<<n<<" "<<k<<endl;
                             //  cout<<"left:"<<left<<" bottom: "<<bottom<<endl;
                             //  }
            
            						Cell* firstCell=currCell;
            						//cout << "x =  " << secDim << endl;
            //						if (bidirection)
            //							cout << "First Cell : m: " <<firstDim << "n:" << secDim << "layer: "<< layer <<endl;
            						//Now go till the last filled cell
            						do
            						{
            							currNetID=currCell->getNetID();//currCell starts at the first cell
            							int tempX, tempY;
            							currCell->getAbsolutePosition(&tempX,&tempY);
            							if(currCell->needsVia2() || currCell->needsVia())
            							{
            								oaRect* via=createVia(currCell, dr,design);
            								if(currNet==NULL)
            									cerr<<"currNet is NULL"<<endl;
            								else via->addToNet(currNet);
            							}
            
            							//if pin, create label
            							if (currCell->isPin())
            							{
            								//Create pin label
            								CreatePinTextLabel(currCell, design,dr);
            							}
            							if(secDim==nTilesSecondDim)
            							{
            								//singlecell_secDim = true;
            								break;
            							}
       
                          currCell = grid->at( secDim, firstDim, layer);
            							secDim++;
            						}
            						while ( (currCell->getStatus() == CellFilled
            							   || currCell->getStatus() == CellContact)
            							   && currCell->getNetID()==firstCell->getNetID());//same net)
            
            						//Now we have found the first empty cell after this segment
            						//endpoint should be the last cell
            						if(secDim==nTilesSecondDim)
            						{
            							currCell = grid->at(  secDim-1 ,firstDim, layer);
            						}
            						else //if we stopped because we found different net or because found an empty cell,
            							//then backup to the last cell
            						{
                          currCell = grid->at( secDim-2 ,firstDim, layer);
            							secDim--;
            						}
            
            						currCell->getAbsolutePosition(&xCenter, &yCenter);
            						//cout << "xCenter: " << xCenter << " extFromCenterX: " << extFromCenterX << " " << endl;
                              
                                      m=0;n=0;k=0;
                                      currCell->getPosition(&m,&n,&k);
                                      if (k>=1) currCell_down=grid->at(m,n,k-1);
                                      currCell_Status=currCell->getStatus();
                              /*        
                               if ( dr.getViaDimensionRule() + 2*dr.getContactViaExtensionRule() > dr.getMetalWidthRule() )
                                 {
                                  right = xCenter + (dr.getViaDimensionRule() / 2 + dr.getContactViaExtensionRule());
                                 }
                                 else
                                 {
                                  right = xCenter + extFromCenterX;
                                 }
                                */
                                right = xCenter + ceil(double(dr.getFattenedWidthRule())/2);      
                                if (singlecell_secDim == false)
                                {
            		             //  cout<<"--------Bidrectional Horizontal Segment EndCell BI--------"<<endl;
                             //  cout<<m<<" "<<n<<" "<<k<<endl;
                             //  cout<<"right: "<<right<<" top: "<<top<<endl;
                               }
             	        
                                   if (singlecell_secDim==false && singlecell_allDim==false)
                                   {
                                   //cout<<"left:"<<left<<" bottom: "<<bottom<<" right: "<<right<<" top:"<<top<<endl;
                       							oaRect* newSeg = oaRect::create(topBlock, layNum, purpNum,
                       									oaBox(left, bottom, right, top));
 
                       							if (newSeg == NULL)
                       								cerr << "newSeg is NULL!" << endl;
                       							else 
                                     {
                       								if (currNet == NULL)
                       									cerr << "currNet is NULL after creation of newSeg" << endl;
                       								else newSeg->addToNet(currNet);
                       							}
                       						}
                                      
		                  } // end of if (currCell->getStatus() == CellFilled|| currCell->getStatus() == CellContact)
				         }//end of while (secDim < nTilesSecondDim)
				//cout << "jumped out!" << endl;
        
			      }//end of for (int firstDim = 0; firstDim < nTilesFirstDim; firstDim++)
        }//end of if(layerinfo.direction==BI)

    }// end of for (int layer = 0; layer < nLayers; layer++)
}// end of function


//Function returns cell at the given indices. However the indices are given 
//as first dimension (perpendicular to routing direction)
//and second dimension (parallel to routing direction)

Cell* RouteGeometry::GetCell(Grid* grid, METAL_LAYER_INFO layerInfo,
        int firstDimIndex, int secDimIndex,
        int layerIndex)
{
    if (layerInfo.direction == VER)
    {
        //vertical so first dim is horiz, and second dim is vertical
        return grid->at(firstDimIndex, secDimIndex, layerIndex);
    } else if ( layerInfo.direction == HOR )
    {
        //horizontal so first dim is vertic, and second dim is horiz
        return grid->at(secDimIndex, firstDimIndex, layerIndex);
    } else if ( layerInfo.direction == BI )
    	return grid->at(firstDimIndex, secDimIndex, layerIndex);
}


bool RouteGeometry::isBackTraceOfCellAdjLayer(Cell* cell, Grid* grid,
                                              int lowerAboveBoth,
                                              Cell*& lowerAboveCell)
{
    lowerAboveCell=NULL;
    //Get m,n,currLayer of cell
    unsigned int m, n, currLayer;
    cell->getPosition(&m, &n, &currLayer);
    //check below
    Cell* below = NULL, *above = NULL;
    if ((currLayer != 0) //if not most bottom layer
         && (lowerAboveBoth==0 || lowerAboveBoth==2))//and flag is above or both
    {
        below = grid->at(m, n, currLayer - 1);
        if (below->getBacktrace() == cell)
        {
            lowerAboveCell=below;
            return true;
        }
    }
    unsigned int nHoriz, nVert, nLayers;
    grid->getDims(&nHoriz, &nVert, &nLayers);
    //check above
    if ((currLayer < nLayers - 1) //if not top most layer
         &&(lowerAboveBoth==1 || lowerAboveBoth==2))//and flag is above or both
    {
        above = grid->at(m, n, currLayer + 1);
        
        if (above->getBacktrace() == cell)
        {
            lowerAboveCell=above;
            return true;
        }
    }
    return false;

}

void RouteGeometry::CreatePinTextLabel(Cell* cell, oaDesign* design,
                                        ProjectDesignRules& dr)
{
    oaBlock* topBlock = design->getTopBlock();
    int pinCenterX, pinCenterY;
    cell->getAbsolutePosition(&pinCenterX, &pinCenterY); //get center
    unsigned int m, n, layer;
    cell->getPosition(&m, &n, &layer);//get indices of this cell
    
    oaPoint textLoc(pinCenterX, 
            pinCenterY);
    oaText::create(topBlock, METAL_LAYERS_INFO[layer].layerNum, PURPOSE_NUM,
            cell->getPinName(),
            textLoc,
            oaTextAlign(oacLowerLeftTextAlign), oaOrient(oacR0),
            oaFont(oacRomanFont), oaDist(1000), false, true, true);
    

}
/*
 * Given this segment, check if it's an endpoint of a segment
 */
bool RouteGeometry::isEndpointOfSegment(Cell* cell, Grid* grid)
{
    //to be an enpoint:
    /*either
     * 1- single cell
     * 2-has a neigbor from either its left or right (if horiz layer)
     * 3-has as neighbor from either its top or bottom (if vertic layer)
     */
    unsigned int m,n,k;
    cell->getPosition(&m,&n,&k);
    unsigned int width, height, nLayers;
    grid->getDims(&width,&height,&nLayers);
    //check if it lies on a  horiz or vertical layer
    bool vertical;
    if(METAL_LAYERS_INFO[k].direction == VER)
    {
        vertical=true;
        //if it's first cell or last then it's an endpoint
        if(n==0||n==height-1)
            return true;
         //check below
        bool belowFilled=false;
        Cell* below=grid->at(m,n-1,k);
        if(below->getStatus()==CellContact || below->getStatus()==CellFilled)
        {
            belowFilled=true;
        }    
         //check above
        bool aboveFilled=false;
        Cell* above=grid->at(m,n+1,k);
        if(above->getStatus()==CellContact || above->getStatus()==CellFilled)
        {
            aboveFilled=true;
        }   
        //if single lonely cell
        if(!(aboveFilled||belowFilled))
            return true;
        if(aboveFilled^belowFilled)//if only one of them filled
            return true;        
    }
    else
    {
        vertical=false;
        if(m==0 ||m==width-1)//if first or last
            return true;
         //check left
        bool leftFilled=false;
        Cell* left=grid->at(m-1,n,k);
        if(left->getStatus()==CellContact || left->getStatus()==CellFilled)
        {
            leftFilled=true;
        }    
         //check right
        bool rightFilled=false;
        Cell* right=grid->at(m+1,n,k);
        if(right->getStatus()==CellContact || right->getStatus()==CellFilled)
        {
            rightFilled=true;
        }   
        //if single lonely cell
        if(!(rightFilled||leftFilled))
            return true;
        if(rightFilled^leftFilled)//if only one of them filled
            return true; 
    }
    return false;    
}
/*
 * This function checks the cell below this cell (i.e. in lower metal layer)
 * and checks its viaNEeded flag and returns it
 */
bool RouteGeometry::hasViaBelow(Cell* currCell, Grid* grid)
{
    //Get m,n,currLayer of cell
    unsigned int m, n, currLayer;
    currCell->getPosition(&m, &n, &currLayer);
    //check below
    Cell* below = NULL, *above = NULL;
    if (currLayer != 0) //if not most bottom layer    
    {
        below = grid->at(m, n, currLayer - 1);
        return below->needsVia();
    }
    return false;
}
//Function only checks if via needs to be created from this cell
//Via needed if this is an M1 cell that has viaNEeded flag on
//or if M2 but M1 cell below has viaNeeded flag on, but 
//the M1 cell is not an enpoint of a segment (so will not be checked for 
//the need of via)
bool RouteGeometry::isViaExtNeeded(Cell* currCell, Grid* grid)
{
     bool viaNeeded=false;
     if(currCell->needsVia())
        viaNeeded=true;
    //other case if this is on M2, then the cell below it on M1 will say if 
    //it needs a via. 
     else
         viaNeeded=hasViaBelow(currCell, grid);
    return viaNeeded;
}

oaRect* RouteGeometry::createVia(Cell* currCell, ProjectDesignRules dr,
                              oaDesign* design)
{
        //decide on via layer
        //if more via layers, this will need to be changed
         unsigned int h, v, layer; 
        currCell->getPosition(&h, &v, &layer);
        int viaLayerIndex;
        if (currCell->needsVia())
        	viaLayerIndex = 0;//layers 0 and 1 map to 0th via layer, then 1..
        else if (currCell->needsVia2())
        	viaLayerIndex = 1;

        //Create via
        int viaLeft, viaBottom, viaRight, viaTop;
        int x, y;
        currCell->getAbsolutePosition(&x, &y);
       
        
        viaLeft = x - static_cast<int>(ceil(dr.getViaDimensionRule() / 2));
        viaRight = x + static_cast<int>(ceil(dr.getViaDimensionRule() / 2));
        viaBottom = y - static_cast<int>(ceil(dr.getViaDimensionRule() / 2));
        viaTop = y + static_cast<int>(ceil(dr.getViaDimensionRule() / 2));
           
        
        return oaRect::create(design->getTopBlock(), VIA_LAYER_NUMBERS[viaLayerIndex],
                PURPOSE_NUM, oaBox(viaLeft, viaBottom, viaRight, viaTop));
}
