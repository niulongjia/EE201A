/* Authors: Mark Gottscho and Yasmine Badr
 * Email: mgottscho@ucla.edu, ybadr@ucla.edu
 * Copyright (C) 2013 Mark Gottscho and Yasmine Badr
 */

#ifndef MAZE_H
#define	MAZE_H

class Maze {
public:
    Maze();
    
    virtual ~Maze();
private:

};

#endif	/* MAZE_H */

