/* Authors: Mark Gottscho and Yasmine Badr
 * Email: mgottscho@ucla.edu, ybadr@ucla.edu
 * Copyright (C) 2013 Mark Gottscho and Yasmine Badr
 */

#include "MazeRouter.h"
#include "Cell.h"
#include "oaDesignDB.h"
#include "Definitions.h"
#include "ClosestPairIndices.h"
#include <iostream>
#include <ctime>
#include <queue>

using namespace oa;
using namespace std;

MazeRouter::MazeRouter()
{
    __Fattened_Width_dbu = 0;
    __Fattened_Width = 0;
    __keepoutRadius_lateral_dbu = 0;
    __keepoutRadius_lateral = 0;
    __keepoutRadius_longitudinal_dbu = 0;
    __keepoutRadius_longitudinal = 0;
    __keepoutRadius_powerRail_dbu = 0;
    __keepoutRadius_powerRail = 0;
    __keepoutRadius_bbox_m1_dbu = 0;
    __keepoutRadius_bbox_m1 = 0;
    __keepoutRadius_bbox_m2_dbu = 0;
    __keepoutRadius_bbox_m2 = 0;
    __keepoutRadius_bbox_m3_dbu = 0;
    __keepoutRadius_bbox_m3 = 0;
    __metal_1_direction = 'X';
    __metal_2_direction = 'X';
    __metal_3_direction = 'X';
    
}

MazeRouter::MazeRouter(vector<Connection>* netlist, ProjectDesignRules* rules, oaInt4 VDD_y, oaInt4 VSS_y, oaBox* design_bbox) : Router(netlist,rules,VDD_y,VSS_y,design_bbox) {
    
    buildGrid();
    oaUInt4 cell_w, cell_h = 0; //assume width=height
    __grid->getCellDims(&cell_w, &cell_h);
    //Lateral keepout radius (for parallel wire segments on same layer): Min metal width + min metal spacing = metal pitch
   
    //__keepoutRadius_lateral_dbu = __rules->getMetalWidthRule() + __rules->getMetalSpaceRule();
    //__keepoutRadius_lateral = __keepoutRadius_lateral_dbu / cell_w;
    
    
    //__Fattened_Width_dbu=(__rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule() > __rules->getMetalWidthRule() ) ?        
    //                           __rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule():
    //                           __rules->getMetalWidthRule();
    __Fattened_Width_dbu=__rules->getFattenedWidthRule();
    __Fattened_Width = ceil(double(__Fattened_Width_dbu)/cell_w);
                             
    __keepoutRadius_lateral_dbu = __Fattened_Width_dbu + __rules->getMetalSpaceRule();
    __keepoutRadius_lateral = ceil(double(__keepoutRadius_lateral_dbu)/cell_w);
    
    //Longitudinal keepout radius (for line ends on same layer): Min metal spacing + 2*extension + contact size to margin for worst case where two contacted line ends are next to each other.
    
    //__keepoutRadius_longitudinal_dbu = __rules->getMetalSpaceRule() + 2*__rules->getContactViaExtensionRule()+__rules->getViaDimensionRule();
    __keepoutRadius_longitudinal_dbu =  __Fattened_Width_dbu + __rules->getMetalSpaceRule();
    __keepoutRadius_longitudinal = ceil(double(__keepoutRadius_longitudinal_dbu) / cell_w);
    
    //power rails don't have contacts nor extensions so we can be more liberal with their keepouts. Should be S+E+V/2
    //__keepoutRadius_powerRail_dbu = __rules->getMetalSpaceRule() + __rules->getContactViaExtensionRule() + __rules->getViaDimensionRule()/2;
    __keepoutRadius_powerRail_dbu = __rules->getMetalSpaceRule() + __Fattened_Width_dbu/2;
    __keepoutRadius_powerRail = ceil(double(__keepoutRadius_powerRail_dbu) / cell_w);
    
    //create bounding box keepout on Metal1 and Metal2
    //__keepoutRadius_bbox_m1_dbu = __rules->getMetalWidthRule() / 2;
    __keepoutRadius_bbox_m1_dbu = ceil(double(__Fattened_Width_dbu)/2);
    __keepoutRadius_bbox_m1 = ceil(double(__keepoutRadius_bbox_m1_dbu) / cell_w);
    //__keepoutRadius_bbox_m2_dbu = __rules->getViaDimensionRule() / 2 + __rules->getContactViaExtensionRule();
    __keepoutRadius_bbox_m2_dbu = ceil(double(__Fattened_Width_dbu)/2);
    __keepoutRadius_bbox_m2 = ceil(double(__keepoutRadius_bbox_m2_dbu) / cell_w);
    //__keepoutRadius_bbox_m3_dbu = __rules->getViaDimensionRule() / 2 + __rules->getContactViaExtensionRule();
    __keepoutRadius_bbox_m3_dbu = ceil(double(__Fattened_Width_dbu)/2);
    __keepoutRadius_bbox_m3 = ceil(double(__keepoutRadius_bbox_m3_dbu) / cell_w);
    
    __metal_1_direction = __rules->getMetal1Direction();
    __metal_2_direction = __rules->getMetal2Direction();
    __metal_3_direction = __rules->getMetal3Direction();
    
    
    cout << "---------------------Basic Information ---------------------"<<endl;
    //cout << "Maze routing lateral keepout radius (DBU): " << __keepoutRadius_lateral_dbu << endl;
    //cout << "Maze routing lateral keepout radius (cells): " << __keepoutRadius_lateral << endl;
    cout << "Fattened Maze routing lateral keepout radius (DBU): " << __Fattened_Width_dbu << endl;
    cout << "Fattened Maze routing lateral keepout radius (cells): " << __Fattened_Width << endl;
    
    cout << "Maze routing longitudinal keepout radius (DBU): " << __keepoutRadius_longitudinal_dbu << endl;
    cout << "Maze routing longitudinal keepout radius (cells): " << __keepoutRadius_longitudinal << endl;
    cout << "Maze routing power rail keepout radius (DBU): " << __keepoutRadius_powerRail_dbu << endl;
    cout << "Maze routing power rail keepout radius (cells): " << __keepoutRadius_powerRail << endl;
    cout << "Maze routing bounding box keepout radius for Metal1 (DBU): " << __keepoutRadius_bbox_m1_dbu << endl;
    cout << "Maze routing bounding box keepout radius for Metal1: " << __keepoutRadius_bbox_m1 << endl;
    cout << "Maze routing bounding box keepout radius for Metal2 (DBU): " << __keepoutRadius_bbox_m2_dbu << endl;
    cout << "Maze routing bounding box keepout radius for Metal2: " << __keepoutRadius_bbox_m2 << endl;
    cout << "Maze routing bounding box keepout radius for Metal3 (DBU): " << __keepoutRadius_bbox_m3_dbu << endl;
    cout << "Maze routing bounding box keepout radius for Metal3: " << __keepoutRadius_bbox_m3 << endl;
    cout << "metal 1 direction:" <<__metal_1_direction<<endl;
    cout << "metal 2 direction:" <<__metal_2_direction<<endl;
    cout << "metal 3 direction:" <<__metal_3_direction<<endl;
    cout << "------------------------------------------------------------"<<endl;
   
    
}

MazeRouter::~MazeRouter()
{
}

bool MazeRouter::route(oaDesign* design) 
{
	 __foundRoute = true; //assume true until we find an issue

    //cout << "Special routing power nets..." << endl;

//	clock_t begin = clock();

    //cout << "Special routing power nets: " << VDD_NET_ID << " for VDD and " << VSS_NET_ID << " for VSS." << endl; //Weiche
    routePowerNet(VDD_NET_ID);
    routePowerNet(VSS_NET_ID);

//	clock_t end = clock();
//	double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
//	cout << "Time Debug: VDD_VSS: " << elapsed_secs << endl;
//	begin = end;

    //Single-contact IO nets: special case. No routing, only pin needed, but it gets high priority.
 //   cout << "Generating pins for single-contact IO nets..." << endl;
    __grid->reset();
    for (oaInt4 net = 2; net < __contactCells.size(); net++) {
        if (__contactCells[net][0]->getNetType() == "IO" && __contactCells[net].size() == 1) { 
            oaUInt4 m,n,k = 0;
            Cell* c = __contactCells[net][0];
            c->getPosition(&m,&n,&k);
            
            
            //We want to do this at the contact M1, since M2 pins are not required.
            //Propagate pin name (used later in creating text label))
            __grid->at(m,n,k)->setPin(true);
            __grid->at(m,n,k)->setPinName(c->getPinName());
            __grid->at(m,n,k)->setSingleCell(true);
           // cout<<"m:"<<m<<" n: "<<n<<" k: "<<k<<" Status():"<<__grid->at(m,n,k)->getStatus()<<endl;
        }
    }
    
//	end = clock();
//	elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
//	cout << "Time Debug: Single IO: " << elapsed_secs << endl;
//	begin = end;

    //Multi-contact IO nets. Need routing. Choose pin location after routing is done
  //  cout << "Maze routing multi-contact IO nets..." << endl;
    for (oaInt4 net = 2; net < __contactCells.size(); net++) {
        if ((__contactCells[net][0]->getNetType() == "IO" && __contactCells[net].size() > 1) ||( __contactCells[net][0]->getNetType() == "S") ) {
            //Clean reset for each net
            __grid->reset();
            //cout<<"-----------------------------netID: "<<net<<" ------------------------"<<endl;
            
            
            generateKeepouts(net);

              
            //Basic approach: route from contact to contact in order of appearance.
            for (oaInt4 contactIndex = 0; contactIndex < __contactCells[net].size()-1; contactIndex++) {
                __grid->softReset(); //Preserve keepouts and cellInViaNet during soft reset so we don't waste time recomputing them
               

                      //oaUInt4 contact0_m, contact0_n, contact0_k,  contact1_m, contact1_n, contact1_k ;
                      oaInt4 contact0_x, contact0_y, contact1_x, contact1_y ;

                      __contactCells[net][contactIndex]->getAbsolutePosition(&contact0_x, &contact0_y ) ;
                      __contactCells[net][contactIndex+1]->getAbsolutePosition(&contact1_x, &contact1_y ) ;
                      

                      int x1 = (contact1_x>contact0_x) ? contact0_x:contact1_x ;
                      int x2 = (contact1_x<contact0_x) ? contact0_x:contact1_x ;
                      int y1 = (contact1_y>contact0_y) ? contact0_y:contact1_y ;
                      int y2 = (contact1_y<contact0_y) ? contact0_y:contact1_y ;
                      
                      int box_w = x2-x1;
                      int box_h = y2-y1;
                     // cout<<"box_w:"<<box_w<<endl;
                     // cout<<"box_h:"<<box_h<<endl;
                     if (box_w<=1*__keepoutRadius_lateral_dbu && box_h<=1*__keepoutRadius_lateral_dbu)
                     {
                      
                       // We need special route here!
                      // cout<<"box_w: "<<box_w<<" box_h: "<<box_h<<endl;
                      // cout<<"contact0  x:"<<contact0_x<<" y: "<<contact0_y<<endl;
                      // cout<<"contact1  x:"<<contact1_x<<" y: "<<contact1_y<<endl;
                       
                        int topBound_V,topBound_H;
                        int bottomBound_V,bottomBound_H;
                        int leftBound_V,leftBound_H;
                        int rightBound_V,rightBound_H;

                        topBound_V = y2 + ceil(double(__rules->getFattenedWidthRule())/2 );
                        bottomBound_V = y1 - ceil(double(__rules->getFattenedWidthRule())/2 );
                        leftBound_V = x1 - ceil(double(__rules->getFattenedWidthRule())/2 );
                        rightBound_V = x1 + ceil(double(__rules->getFattenedWidthRule())/2 );   
                        
                        topBound_H = y1 + ceil(double(__rules->getFattenedWidthRule())/2 );
                        bottomBound_H = y1 - ceil(double(__rules->getFattenedWidthRule())/2 );
                        leftBound_H = x1 - ceil(double(__rules->getFattenedWidthRule())/2 );
                        rightBound_H = x2 + ceil(double(__rules->getFattenedWidthRule())/2 );      

                        int layer=0;
                         oaBlock* topBlock = design->getTopBlock();
                         oaPurposeNum purpNum = 1; //LPPHeader->getPurposeNum();
                         oaLayerNum layNum=METAL_LAYERS_INFO[layer].layerNum;
                         
                         oaRect* newSeg_V = oaRect::create(topBlock, layNum, purpNum,
              								      oaBox(leftBound_V, bottomBound_V, rightBound_V, topBound_V));
                                   
              						          if (newSeg_V == NULL)
              							        cerr << "newSeg_V is NULL!" << endl;
                             //       else
                             //       {
                             //       cout<<" newSeg_V complete"<<endl;
                             //       cout<<"leftBound_V"<<leftBound_V<<"bottomBound_V"<<bottomBound_V<<"rightBound_V"<<rightBound_V<<"topBound_V"<<topBound_V<<endl;                     
                              //      }
                         oaRect* newSeg_H = oaRect::create(topBlock, layNum, purpNum,
              								      oaBox(leftBound_H, bottomBound_H, rightBound_H, topBound_H));
              
              						          if (newSeg_H == NULL)
              							        cerr << "newSeg_H is NULL!" << endl;
                              //      else
                              //      {
                              //      cout<<" newSeg_H complete"<<endl;
                              //      cout<<"leftBound_H"<<leftBound_H<<"bottomBound_H"<<bottomBound_H<<"rightBound_H"<<rightBound_H<<"topBound_H"<<topBound_H<<endl;                     
                              //      }
                     }
                 
                 
               
                if ( __contactCells[net][0]->getNetType() == "S")
                {
                  	mazeRouteAStar(net, contactIndex+1, contactIndex, false);
//                	mazeRoute(net, contactIndex+1, contactIndex, false);
                      
                }
                else if (contactIndex == 0 ) //set pin during first segment
                {
                	  mazeRouteAStar(net, contactIndex+1, contactIndex, true);
//                	mazeRoute(net, contactIndex+1, contactIndex, true);
                      
                }
                else  
                {
               	  mazeRouteAStar(net, contactIndex+1, contactIndex, false);
//                	mazeRoute(net, contactIndex+1, contactIndex, false);


                } 

            }

        }
    }

   
    __grid->reset();

	
	 return __foundRoute;
}

void MazeRouter::buildGrid() {
  //  cout << "MazeRouter is building the Grid..." << endl;
    
    //First, determine the dimension (width, height) of each cell in DBU. For MazeRouter, width and height should be equal.
    oaUInt4 cell_dim_x = cellDim_fine();
    oaUInt4 cell_dim_y = cellDim_fine();

    
    //Next, determine the number of cells in each dimension (m,n,k). The Grid should fit entirely INSIDE the design bounding box so we don't accidentally route outside.
    oaUInt4 design_width = __design_bbox->getWidth();
    oaUInt4 design_height = __design_bbox->getHeight();
    oaUInt4 m = 1;
    oaUInt4 n = 1;
    oaUInt4 k = 1;
   
    m = design_width / cell_dim_x;
    n = design_height / cell_dim_y;
    k = 3; //Fixed for two-layer maze routing
    
    //Next, determine the origin (x0,y0) of the bottom-left-most cell on layer 0, relative to origin of design in DBU
    oaInt4 cell0_x = 0;
    oaInt4 cell0_y = 0;
    
    cell0_x = __design_bbox->lowerLeft().x() + cell_dim_x/2;
    cell0_y = __design_bbox->lowerLeft().y() + cell_dim_y/2;
	//cout<<"Orig y: "<<__design_bbox->lowerLeft().y()<<endl; //Weiche
    __grid = new Grid(m,n,k,cell_dim_x,cell_dim_y,cell0_x,cell0_y);
  //  cout << "Initializing grid..." << endl;
    initializeGrid();
    __grid->printStats();
}

oaUInt4 MazeRouter::cellDim_coarse() {
    //Cell dim should be max(metalwidth, metalspace) + 2*viaextensionrule. Note we assume via/contact dimensions <= metal width always.
    oaUInt4 cell_dim = 0;
    
    if (__rules->getMetalSpaceRule() > __rules->getMetalWidthRule())
        cell_dim = __rules->getMetalSpaceRule();
    else
        cell_dim = __rules->getMetalWidthRule();
    cell_dim += 2*__rules->getContactViaExtensionRule();
    if (cell_dim % 2 == 1) //odd, round up to even number
        cell_dim++;      
    
    return cell_dim;
}

oaUInt4 MazeRouter::cellDim_fine() {
    //Cell dim should be 5nm x 5nm = 50 DBU x 50 DBU.
    return 50;     
}

void MazeRouter::initializeGrid() {
    __grid->reset();
    
    //Map each net's contacts to grid cells     
 //   cout << "Mapping net contacts to grid cells, netlist size = "<< __netlist->size() << "..." << endl;
    for (int i = 0; i < __netlist->size(); i++) {
        Connection c = __netlist->at(i);
        //cout << "...Setting up net " << i << " which has type " << c.netType << "..." << endl;
        vector<Cell*> temp; //vector of Cells containing contacts for this net
        for (int j = 0; j < c.contactCoords.size(); j++) {
            oaPoint p = c.contactCoords.at(j);
            oaInt4 x = p.x();
            oaInt4 y = p.y();
            //cout << "before __grid->atXY x="<<x<<" y="<<y << endl;
            Cell* contactCell = __grid->atXY(x,y,0);
            //cout << "after __grid->atXY" << endl;
            oaUInt4 m,n,k = 0;
            contactCell->getPosition(&m,&n,&k);
            //cout << "...... contact origin at (" << x << "," << y << ") DBU, which corresponds to Grid Cell (" << m << "," << n << "," << k << ")" << endl;
            contactCell->setNetID(i);
            contactCell->setNetType(oaString(c.netType.c_str()));
            contactCell->setPinName(c.pinName.c_str()); 
            contactCell->setStatus(CellContact);
         
            temp.insert(temp.end(),contactCell);
        }
        __contactCells.insert(__contactCells.end(), temp);
    }
    
    //Map VDD/VSS rails to cells
 //   cout << "Mapping power rails to grid cells..." << endl;
    oaUInt4 dim_m, dim_n, dim_k = 0;
    oaInt4 x,y = 0;  
    __grid->getDims(&dim_m, &dim_n, &dim_k);
    
    for (oaUInt4 m = 0; m < dim_m; m++) {
        for (oaUInt4 n = 0; n < dim_n; n++) {
            __grid->at(m,n,0)->getAbsolutePosition(&x,&y);
			//cout<<"x="<<x<<" y="<<y<<" __VDD_y="<<__VDD_y<<" __VSS_y="<<__VSS_y<<"\n"; //Weiche
            if (y >= __VDD_y) {
                __grid->at(m,n,0)->setNetType("VDD");
                __grid->at(m,n,0)->setNetID(VDD_NET_ID);
                __grid->at(m,n,0)->setStatus(CellVDDRail);
            } else if (y <= __VSS_y) {
                __grid->at(m,n,0)->setNetType("VSS");
                __grid->at(m,n,0)->setNetID(VSS_NET_ID);
                __grid->at(m,n,0)->setStatus(CellVSSRail);
            } 
        }
    }
    
  //  cout << "Finished initializing the Grid." << endl;
}

void MazeRouter::routePowerNet(oaInt4 nid) {
    //We assume that each contact that needs to connect to VDD can route directly up in Metal1.
    //We assume that each contact that needs to connect to VSS can route directly down in Metal1.
    //This appears reasonable with the given test cases, and the knowledge of P/N diffusion regions and normal CMOS logic.
    oaUInt4 dim_m, dim_n, dim_k = 0;
    __grid->getDims(&dim_m, &dim_n, &dim_k);

    //cout << "In routePowerNet! dim_m = " << dim_m << " dim_n = " << dim_n << endl; //Weiche
    //Let's loop through all contacts that are on the net, and generate their routes one-by-one.
    for (oaInt4 i = 0; i < __contactCells[nid].size(); i++) {
        Cell* contact = __contactCells[nid][i];
        oaUInt4 m,n,k = 0;
        contact->getPosition(&m, &n, &k);
        oaInt4 j = n;
        bool done = false;
		//int nCellsInRail=11; //Weiche
		//int nCellsInRail=0; //Weiche	
			while (!done) { //Iterate through cells until we hit a rail
            //cout<<"before at m="<<m<<" j="<<j<<" k="<<k<<endl; //Weiche
			Cell* curr = __grid->at(m,j,k);
            //cout<<"after at m="<<m<<" j="<<j<<" k="<<k; //Weiche
			CellStatus status = curr->getStatus();
            oaUInt4 net_id = curr->getNetID();

            switch (status) {
                case CellVDDRail:
				//cout<<"  case CellVDDRail"<<endl; //Weiche
                    if (nid == VDD_NET_ID)
					            {
                        done = true;
					            }
                    else {
                        cout << "Somehow hit the VDD rail while routing VSS!" << endl;
						__foundRoute = false;
                        //__grid->print();
                        exit(1);
                    }
                    break;
                case CellVSSRail:
                    //cout<<"  case CellVSSRail"<<endl; //Weiche
                    if (nid == VSS_NET_ID)
                    {
                        done = true;
				            }
                    else {
                        cout << "Somehow hit the VSS rail while routing VDD!" << endl;
						__foundRoute = false;
                        //__grid->print();
                        exit(1);
                    }
                    break;
                case CellFilled:
              
                case CellContact:
				 
                    if (net_id != nid) {
	
                        cout << "We have a problem routing power net " << contact->getNetType() << "! We hit an occupied cell that wasn't ours. Here's the Grid." << endl;
						__foundRoute = false;

                        exit(1);
                    }
                    break;
                case CellKeepout:

                    cout << "We have a problem routing power net " << contact->getNetType() << "! We hit a keepout region. Here's the Grid." << endl;
                    __foundRoute = false;
                    __grid->print();
                    exit(1);
                    break;
                case CellFree:

                    curr->setStatus(CellFilled);
                    curr->setNetType(contact->getNetType());
                    curr->setNetID(nid);
                    break;
            }
                       
            if (nid == VDD_NET_ID) {
                //create backtrace
                if (i > 0)
                    curr->setBacktrace(__grid->at(m,j-1,k));
                j++;
            } else {
                //create backtrace
                if (i > 0)
                    curr->setBacktrace(__grid->at(m,j+1,k));
                j--;
            }
        }       
    }
} 

void MazeRouter::mazeRoute(oaUInt4 netID, oaInt4 contactIndex0, oaInt4 contactIndex1, bool setPin) { //Lee's algorithm

    //cout<<"__metal_1_direction: "<<__metal_1_direction<<endl;
    //cout<<"__metal_2_direction: "<<__metal_2_direction<<endl;
    //cout<<"__metal_3_direction: "<<__metal_3_direction<<endl;
    bool setpinfinal=setPin;
	//First, choose two endpoints to connect, and set them as source and sink.
    oaUInt4 dim_m, dim_n, dim_k = 0;
    __grid->getDims(&dim_m,&dim_n,&dim_k);
    //cout << "Dimension of Grid" << dim_m << dim_n  << dim_k <<endl;

    oaUInt4 m,n,k,m2,n2,k2 = 0;

    __contactCells[netID][contactIndex0]->getPosition(&m,&n,&k);
    __contactCells[netID][contactIndex1]->getPosition(&m2,&n2,&k2);

	Cell* source = __contactCells[netID][contactIndex0];
	Cell* sink = __contactCells[netID][contactIndex1];

//    if ( __grid->disToCenter(m,n) <  __grid->disToCenter(m2,n2))
//    {
//
//    	source = __contactCells[netID][contactIndex1];
//    	sink = __contactCells[netID][contactIndex0];
//    	cout << "Source Selection: Cell2 is swapped as source"  <<endl;
//    }




    source->setIsRouted();
    
    source->setSource(true);
    sink->setSink(true);
    
    oaUInt4 sourcem, sourcen, sourcek = 0;
    oaUInt4 farmingBoundn = 15;
	oaUInt4 farmingBoundm = 15;

    oaInt4 sourceNetID = source->getNetID();
    oaUInt4 sinkm, sinkn, sinkk = 0;
    oaUInt4 mmin, nmin, mmax,nmax = 0;

    source->getPosition(&sourcem,&sourcen,&sourcek);
    sink->getPosition(&sinkm,&sinkn,&sinkk);


	if (sinkm > sourcem)
	{
		mmin = sourcem;
		mmax = sinkm;
	} else
	{
		mmin = sinkm;
		mmax = sourcem;
	}

	if (sinkn > sourcen)
	{
		nmin = sourcen;
		nmax = sinkn;
	} else
	{
		nmin = sinkn;
		nmax = sourcen;
	}



    //cout<<"source m: "<<(int)sourcem<<" sourcen "<<(int)sourcen<<endl;  //Weiche
    //Next, initialize our plist and nlist (two adjacent BFS wavefronts)
    vector<Cell*> plist;
    vector<Cell*> nlist;
    vector<Cell*> neighbors;
    bool path_exists = false;
    oaUInt4 dist = 0;
    Cell* curr = NULL;



    plist.push_back(source); //we start with the source only.
    while (plist.size() > 0 && !path_exists) 
    {
        //One wave
        for (int p = 0; p < plist.size(); p++) 
        {
            curr = plist[p];
            //Iterate over neighbors of curr
            curr->getPosition(&m,&n,&k);
            neighbors.clear();

            if (k == 0) //M1 Layer
            { 
              switch (__metal_1_direction)
              {
               case 'V':
              	if (n-1 >= (nmin-farmingBoundn))
            	  	neighbors.push_back(__grid->at(m,n-1,k));
                if (n+1 <= (nmax+farmingBoundn))
                	neighbors.push_back(__grid->at(m,n+1,k));
                 
                neighbors.push_back(__grid->at(m,n,k+1)); //above
                 break;
                 
               case 'H':
                if (m-1 >= (mmin-farmingBoundm))
                	neighbors.push_back(__grid->at(m-1,n,k));
                if (m+1 <= (mmax+farmingBoundm))
                	neighbors.push_back(__grid->at(m+1,n,k));

                neighbors.push_back(__grid->at(m,n,k+1)); //above 
                 break;
                 
               case 'B':
               
                  if (n-1 >= (nmin-farmingBoundn))
            		    neighbors.push_back(__grid->at(m,n-1,k));
                  if (n+1 <= (nmax+farmingBoundn))
                	  neighbors.push_back(__grid->at(m,n+1,k));
                  if (m-1 >= (mmin-farmingBoundm))
                   	neighbors.push_back(__grid->at(m-1,n,k));
                  if (m+1 <= (mmax+farmingBoundm))
                	  neighbors.push_back(__grid->at(m+1,n,k));
                     
                  neighbors.push_back(__grid->at(m,n,k+1)); //above
                  
                  //cout<<"wave!"<<endl;
                 break;              
              }

            }
            else if (k == 1) // M2 Layer
            { 
              switch (__metal_2_direction)
              {
               case 'V':
              	if (n-1 >= (nmin-farmingBoundn))
            	  	neighbors.push_back(__grid->at(m,n-1,k));
                if (n+1 <= (nmax+farmingBoundn))
                	neighbors.push_back(__grid->at(m,n+1,k));
                 
                neighbors.push_back(__grid->at(m,n,k+1)); //above 
                neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;
                 
               case 'H':
                if (m-1 >= (mmin-farmingBoundm))
                	neighbors.push_back(__grid->at(m-1,n,k));
                if (m+1 <= (mmax+farmingBoundm))
                	neighbors.push_back(__grid->at(m+1,n,k));

                neighbors.push_back(__grid->at(m,n,k+1)); //above 
                neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;
                 
               case 'B':
                  if (n-1 >= (nmin-farmingBoundn))
            		    neighbors.push_back(__grid->at(m,n-1,k));
                  if (n+1 <= (nmax+farmingBoundn))
                	  neighbors.push_back(__grid->at(m,n+1,k));
                  if (m-1 >= (mmin-farmingBoundm))
                   	neighbors.push_back(__grid->at(m-1,n,k));
                  if (m+1 <= (mmax+farmingBoundm))
                	  neighbors.push_back(__grid->at(m+1,n,k));
                  
                  neighbors.push_back(__grid->at(m,n,k+1)); //above   
                  neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;              
              }
            } 
            else if(k == 2) // M3 Layer
            {
            	 switch (__metal_3_direction)
              {
               case 'V':
              	if (n-1 >= (nmin-farmingBoundn))
            	  	neighbors.push_back(__grid->at(m,n-1,k));
                if (n+1 <= (nmax+farmingBoundn))
                	neighbors.push_back(__grid->at(m,n+1,k));
                 
                neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;
                 
               case 'H':
                if (m-1 >= (mmin-farmingBoundm))
                	neighbors.push_back(__grid->at(m-1,n,k));
                if (m+1 <= (mmax+farmingBoundm))
                	neighbors.push_back(__grid->at(m+1,n,k));

                neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;
                 
               case 'B':
                  if (n-1 >= (nmin-farmingBoundn))
            		    neighbors.push_back(__grid->at(m,n-1,k));
                  if (n+1 <= (nmax+farmingBoundn))
                	  neighbors.push_back(__grid->at(m,n+1,k));
                  if (m-1 >= (mmin-farmingBoundm))
                   	neighbors.push_back(__grid->at(m-1,n,k));
                  if (m+1 <= (mmax+farmingBoundm))
                	  neighbors.push_back(__grid->at(m+1,n,k));
                    
                  neighbors.push_back(__grid->at(m,n,k-1)); //below
                 break;              
              }
            }

            Cell* next = NULL;
            CellStatus nextstatus;
            oaInt4 netID = -1;
            for (int d = 0; d < neighbors.size(); d++) 
            {
                next = neighbors[d];   
                nextstatus = next->getStatus();
                netID = next->getNetID();
                if (!next->touched() && //cell must NOT be touched and...
                        (nextstatus == CellFree || //free, or
                                ((nextstatus == CellFilled || nextstatus == CellContact) && //filled or contact, and...
                                        netID == sourceNetID))) //same net ID as source.
                { 
                 oaUInt4 nextm,nextn,nextk=0;
                 next->getPosition(&nextm,&nextn,&nextk);
                 //if ((sinkm==53) && (sinkn==225))
                 //cout<<nextm<<" "<<nextn<<" "<<nextstatus<<endl;
                 
                    next->touch();
                    
                    next->setDistance(dist+1);
                    next->setBacktrace(curr);
                    nlist.push_back(next);
                    if (next->isSink() ) { //HURRAY WE FOUND IT
                    	setpinfinal = setPin;
                        path_exists = true;
                    }

                    else if ( (nextstatus == CellFilled || nextstatus == CellContact) && (netID == sourceNetID) && (next != source) && (next->isRouted()))
                    {
                    	path_exists = true;
                    	sink->setSink(false);
                    	sink = next;
                    	sink->setSink(true);
                    	sink->getPosition(&sinkm,&sinkn,&sinkk);
                    	setpinfinal = true;
                    	if ( nextstatus == CellContact)
                    		setpinfinal = false;

                    }

                }
            }
          // if ((sinkm==53) && (sinkn==225)) cout<<"End of this wave HAHA"<<endl;
        }// end of <for (int p = 0; p < plist.size(); p++)>
        dist++;
        plist = nlist;
        nlist.clear();
    }// end of <while (plist.size() > 0 && !path_exists)>
    
    if (path_exists) {

        //cout << "Found a path from Cell (" << sourcem << "," << sourcen << "," << sourcek << ") to (" << sinkm << "," << sinkn << "," << sinkk << ")" << endl;

        doBacktrace(source, sink, setpinfinal);
    } else {
   
        cout << "DID NOT find a path from Cell (" << sourcem << "," << sourcen << "," << sourcek << ") to (" << sinkm << "," << sinkn << "," << sinkk << ")" << endl;
		  __foundRoute = false;
    }   
}


void MazeRouter::mazeRouteAStar(oaUInt4 netID, oaInt4 contactIndex0, oaInt4 contactIndex1, bool setPin) { //A* search
    bool setpinfinal=setPin;
	//First, choose two endpoints to connect, and set them as source and sink.
    oaUInt4 dim_m, dim_n, dim_k = 0;
    __grid->getDims(&dim_m,&dim_n,&dim_k);
    //cout << "Dimension of Grid" << dim_m << dim_n  << dim_k <<endl;

    oaUInt4 m,n,k,m2,n2,k2 = 0;

	Cell* source = __contactCells[netID][contactIndex0];
	Cell* sink = __contactCells[netID][contactIndex1];

    source->setIsRouted();

    source->setSource(true);
    sink->setSink(true);
    oaInt4 sourceNetID = source->getNetID();

    oaUInt4 sinkm, sinkn, sinkk = 0;
    oaUInt4 sourcem, sourcen, sourcek = 0;
    oaUInt4 nextm, nextn, nextk = 0;

    source->getPosition(&sourcem,&sourcen,&sourcek);
    sink->getPosition(&sinkm,&sinkn,&sinkk);

    oaUInt4 Hneed = 0;
    if (sinkm != sourcem)
    {
    	Hneed = 1;
    }

//    oaInt4 farmingBoundn = 30;
//	oaInt4 farmingBoundm = 30;
//    oaInt4 mmin, nmin, mmax,nmax = 0;
//
//	if (sinkm > sourcem)
//	{
//		mmin = sourcem;
//		mmax = sinkm;
//	} else
//	{
//		mmin = sinkm;
//		mmax = sourcem;
//	}
//
//	if (sinkn > sourcen)
//	{
//		nmin = sourcen;
//		nmax = sinkn;
//	} else
//	{
//		nmin = sinkn;
//		nmax = sourcen;
//	}


	oaInt4 dirMetal1 = 1;
	oaInt4 dirMetal2 = 2;
	oaInt4 dirMetal3 = 3;





   // cout<<"DEBUG: source m: "<<(int)sourcem<<" sourcen "<<(int)sourcen<<endl;  //Weiche
   // cout<<"DEBUG: sink m: "<<(int)sinkm<<" sink "<<(int)sinkn<<endl;  //Weiche
    //Next, initialize our plist and nlist (two adjacent BFS wavefronts)
    //vector<Cell*> closelist;
    vector<Cell*> neighbors;
    bool path_exists = false;
    oaUInt4 dist = 0;
    Cell* curr = NULL;
    Cell* left = NULL;
    Cell* right = NULL;
    Cell* up = NULL;
    Cell* down = NULL;
    Cell* above = NULL;
    Cell* below = NULL;
    Cell* best = NULL;
    bool sameNetorFree = false;
    bool foundmin =false;

	oaUInt4 minhcost = 10000;
	oaUInt4 minfCost = 10000;
	oaUInt4 deleteIndex = 0;

	oaUInt4 switchLayerDist;

    //vector<Cell*> openlist;

	priority_queue<Cell*,vector<Cell*>, CellCompare > openlist;

	switchLayerDist = 2 * Hneed;
    curr = source;

    curr->setfCost(curr->getDistanceTo(sinkm,sinkn,sinkk) + dist + switchLayerDist);
    curr->setgCost(dist);
    curr->sethCost(curr->getDistanceTo(sinkm,sinkn,sinkk)+ switchLayerDist);
    curr->touch();

    //openlist.push_back(curr); //we start with the source only.
    openlist.push(curr);
    curr->putOpen(true);
    while ( !path_exists && (openlist.size()>0)) {
//    	curr = openlist[0];
    	curr = openlist.top();
//		for (int i = 1; i < openlist.size(); i++) {
//			if( openlist[i]->getfCost() < curr->getfCost()) //||
//					//(openlist[i]->getfCost() == curr->getfCost()  &&  openlist[i]->gethCost() < curr->gethCost()))
//			{
//				curr = openlist[i];
//				deleteIndex = i;
//			}
//		}
//		openlist.erase((openlist.begin() + deleteIndex));
		openlist.pop();
		curr->putOpen(false);
    	//closelist.push_back(curr);
    	curr->putClose(true);

		CellStatus nextstatus;
		oaInt4 netID = -1;
		nextstatus = curr->getStatus();
	    netID = curr->getNetID();

		if (curr->isSink() ) { //HURRAY WE FOUND IT
			setpinfinal = setPin;
			path_exists = true;
		}
		else if ( (nextstatus == CellFilled || nextstatus == CellContact) && (netID == sourceNetID) && (curr != source) && (curr->isRouted()))
		{
			path_exists = true;
			sink->setSink(false);
			sink = curr;
			sink->setSink(true);
			sink->getPosition(&sinkm,&sinkn,&sinkk);
			setpinfinal = true;
			if ( nextstatus == CellContact)
				setpinfinal = false;
		}


    	neighbors.clear();
		//Iterate over neighbors of curr
		curr->getPosition(&m,&n,&k);
//		if (k == 2)
		//cout << "DEBUG: Current Cell @ m: " << m << " n: " << n<<" k: "<<k <<" gCost:"<<curr->getgCost()<<" fCost:"<<curr->getfCost()<<endl;
		if (n-1 > 0)
			down = __grid->at(m,n-1,k);
		if (n+1 < dim_n)
			up = __grid->at(m,n+1,k);
		if (m-1 > 0)
			left = __grid->at(m-1,n,k);
		if (m+1 < dim_m)
			right = __grid->at(m+1,n,k);
//		cout << "TestTest before add above" << endl;
		if (k <= 1){
			above = __grid->at(m,n,k+1);
//			cout << "TestTest after add above" << endl;
		}
		if (k >= 1){
			below = __grid->at(m,n,k-1);
		}

		dist++;
		if (k == 0) { //bottom layer, M1, route vertically only


			switch (__metal_1_direction)
		    {
				case 'V':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))

					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);

					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))

					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);


					}
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))
					{
						above->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);
					}
					break;

				case 'H':
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))

					{
						above->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);
					}
					break;
				case 'B':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))
					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);
					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))
					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);
					}
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}
				//	cout << "DEBUG: above pushed @ m:  Status : " << above->getStatus() << " NetID " << above->getNetID()<<" touched: "<<above->touched() <<endl;
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))
					{
						above->setgCost(dist);
					//	cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);

					}
					break;

		    }
		}
		else if (k == 1)
		{

                                    
			switch (__metal_2_direction)
			{
				case 'V':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))
					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);
					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))
					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);
					}
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))
					{
						above->setgCost(dist);
					//	cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);
					}
					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);

					}
					break;

				case 'H':
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))

					{
						above->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);
					}
					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);
					}
					break;
				case 'B':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))
					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);
					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))
					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);
					}
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}
					if ( !above->touched() && (above->getStatus() == CellFree || //free, or
										((above->getStatus() == CellFilled || above->getStatus() == CellContact) &&
												above->getNetID() == sourceNetID)))
					{
						above->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k+1 <<endl;
						neighbors.push_back(above);
						above->touch();
						//above->setBacktrace(curr);
					}
					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);
					}
					break;
			}
		}
		else if(k == 2)
		{


			switch (__metal_3_direction)
			{
				case 'V':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))
					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);
					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))
					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);
					}

					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);
					}
					break;

				case 'H':
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}

					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);
					}
					break;
				case 'B':
					if (!up->touched() && (up->getStatus() == CellFree || //free, or
							((up->getStatus() == CellFilled || up->getStatus() == CellContact) &&
							up->getNetID() == sourceNetID)))
					{
						up->setgCost(dist);
						neighbors.push_back(up);
						up->touch();
//						cout << "DEBUG: up pushed @ m: " << m << " n: " << n-1<<" k: "<<k <<endl;
						//up->setBacktrace(curr);
					}
					if (!down->touched() && (down->getStatus() == CellFree || //free, or
							((down->getStatus() == CellFilled || down->getStatus() == CellContact) &&
									down->getNetID() == sourceNetID)))
					{
						down->setgCost(dist);
						neighbors.push_back(down);
						down->touch();
//						cout << "DEBUG: down pushed @ m: " << m << " n: " << n+1<<" k: "<<k <<endl;
						//down->setBacktrace(curr);
					}
					if ( !left->touched() && (left->getStatus() == CellFree || //free, or
											((left->getStatus() == CellFilled || left->getStatus() == CellContact) &&
													left->getNetID() == sourceNetID)))
					{
						left->setgCost(dist);
						neighbors.push_back(left);
						left->touch();
//						cout << "DEBUG: left pushed @ m: " << m-1 << " n: " << n<<" k: "<<k <<endl;
						//left->setBacktrace(curr);
					}
					if (!right->touched() && (right->getStatus() == CellFree || //free, or
							((right->getStatus() == CellFilled || right->getStatus() == CellContact) &&
									right->getNetID() == sourceNetID)))
					{
						right->setgCost(dist);
						neighbors.push_back(right);
						right->touch();
//						cout << "DEBUG: right pushed @ m: " << m+1 << " n: " << n<<" k: "<<k <<endl;
						//right->setBacktrace(curr);
					}

					if ( !below->touched() && (below->getStatus() == CellFree || //free, or
										((below->getStatus() == CellFilled || below->getStatus() == CellContact) &&
												below->getNetID() == sourceNetID)))
					{
						below->setgCost(dist);
//						cout << "DEBUG: above pushed @ m: " << m << " n: " << n<<" k: "<<k-1<<endl;
						neighbors.push_back(below);
						below->touch();
						//above->setBacktrace(curr);
					}
					break;
			}
		}


//		Cell* next = NULL;
//		oaUInt4 cost;
//        CellStatus nextstatus;
//		Cell* minCostCell= NULL;
//		int minCostCellIndex = 0;
		//foundmin =false;
		for (int d = 0; d < neighbors.size(); d++) {
			if(neighbors[d]->inClose()){
			    /*  contains  */
//				cout << " Closed list contains Neightbor!! " << endl;
			} else {/*  does not contain  */
				neighbors[d]->getPosition(&m2,&n2,&k2);
				Hneed = 0;

				if (k2 == 0)
				{
//					Hneed = 0;
//					switch (__metal_1_direction)
//					{
//						case 'V':
//							if ( m2 != sinkm )
//							{
//								Hneed = 2;
//							}
//							break;
//						case 'H':
//							if ( n2 != sinkn )
//							{
//								Hneed = 2;
//							}
//							break;
//						case 'B':
//							Hneed = 0;
//							break;
//					}
				} else if (k2 == 1)
				{
					Hneed = -1;
//					switch (__metal_2_direction)
//					{
//						case 'V':
//							if ( m2 != sinkm )
//							{
//								Hneed = 2;
//							}
//							break;
//						case 'H':
//							if ( n2 != sinkn )
//							{
//								Hneed = 2;
//							}
//							break;
//						case 'B':
//							Hneed = 0;
//							break;
//					}
				}
				else if (k2 == 2)
				{
					Hneed = -2;
//					switch (__metal_2_direction)
//					{
//						case 'V':
//							if ( m2 != sinkm )
//							{
//								Hneed = -2;
//							}
//							break;
//						case 'H':
//							if ( n2 != sinkn )
//							{
//								Hneed = -2;
//							}
//							break;
//						case 'B':
//							Hneed = -2;
//							break;
//					}
				}

				oaUInt4 newgcost = curr->getgCost()+1;
				if ( newgcost < neighbors[d]->getgCost() ||
						!(neighbors[d]->inOpen()))
				{
					neighbors[d]->setgCost(newgcost);
					neighbors[d]->sethCost(neighbors[d]->getDistanceTo(sinkm,sinkn,sinkk)+ Hneed);
					neighbors[d]->setfCost(neighbors[d]->getDistanceTo(sinkm,sinkn,sinkk)+ Hneed + newgcost);
					neighbors[d]->setBacktrace(curr);
					if(!neighbors[d]->inClose())
					{
					//	cout << "DEBUG:Cell added to openlist @ m: " << m2 << " n: " << n2<<" k: "<<k2 <<" G Cost:" <<newgcost<< "F COST: "<< curr->getDistanceTo(sinkm,sinkn,sinkk)+ Hneed + newgcost<<endl;
//						cout << "DEBUG:Cell added to openlist @ Hcost "<< neighbors[d]->getDistanceTo(sinkm,sinkn,sinkk)+ Hneed<< endl;
						//openlist.push_back(neighbors[d]);
						openlist.push(neighbors[d]);
						neighbors[d]->putOpen(true);
					}

				}
			}

		}
		//dist++;
    }

    if (path_exists) {

        //cout << "Found a path from Cell (" << sourcem << "," << sourcen << "," << sourcek << ") to (" << sinkm << "," << sinkn << "," << sinkk << ")" << endl;

        doBacktrace(source, sink, setpinfinal);
    } else {
        cout << "DID NOT find a path from Cell (" << sourcem << "," << sourcen << "," << sourcek << ") to (" << sinkm << "," << sinkn << "," << sinkk << ")" << endl;
		  __foundRoute = false;
    }
}

void MazeRouter::doBacktrace(Cell* source, Cell* sink, bool setPin) {
    Cell* curr = sink;
    Cell* tmp = NULL;
    Cell* tmpPrev = NULL;
    oaUInt4 currm,currn,currk = 0;
    oaUInt4 tmpm,tmpn,tmpk = 0;
    oaUInt4 tmpPrevm,tmpPrevn,tmpPrevk = 0;
   // cout << "DEBUG: backtrace Start!!!!!" <<endl;
    //Handle pin
    if (setPin) {
        curr->getPosition(&currm,&currn,&currk);
        tmp = curr->getBacktrace();
        tmp->getPosition(&tmpm,&tmpn,&tmpk);
        tmpPrev = tmp->getBacktrace();
        tmpPrev->getPosition(&tmpPrevm,&tmpPrevn,&tmpPrevk);
        
        if (currm == tmpm && currn == tmpn && currk == (tmpk-1)) { //backtrace is above the contact, set pin on M2 (the backtraced cell).
        	if (currm == tmpm && currn == tmpn && currk == (tmpPrevk-2))
        	{
        		tmpPrev->setPin(true);
        		tmpPrev->setPinName(source->getPinName());
        	}
        	else
        	{
				tmp->setPin(true);
				tmp->setPinName(source->getPinName());
        	}
        }
        else { //set pin on the contact (sink)
            curr->setPin(true);
        }
    }
    
    // backtrace sink to source
    curr = sink;
    tmp = curr;
    while (tmp != source) 
    {       
        if (curr->getStatus() == CellFree) 
        {
            curr->setStatus(CellFilled);
            curr->setNetID(source->getNetID());
            curr->setNetType(source->getNetType());
        }
        
        //check if we need a via.
		  oaInt4 currm_dbu, currn_dbu = 0;
		  oaInt4 tmpm_dbu, tmpn_dbu = 0;
        curr->getPosition(&currm, &currn, &currk);
		  curr->getAbsolutePosition(&currm_dbu,&currn_dbu);
        tmp->getPosition(&tmpm,&tmpn,&tmpk);
		  tmp->getAbsolutePosition(&tmpm_dbu,&tmpn_dbu);
        
        //For Vertical same net violations
        
        //bool tooClose2=false;//right
        //bool tooClose1=false;//left


        
        //cout<<"netType:"<<source->getNetType()<<" m: "<<tmpm<<" n: "<<tmpn<<" k: "<<tmpk<<endl;


        if (currk == 0 && tmpk == 1) { //change from layer 1 to layer 0
            //set via on curr, which is M1.
            curr->setNeedsVia();
           // cout << "Via needed (M2->M1) at cell (" << currm << "," << currn << "," << currk << ") ---> (" << currm_dbu << "," << currn_dbu << ")" << endl;
        }
        else if (currk == 1 && tmpk == 0) { //change from layer 0 to layer 1
            //set via on tmp, which is M1.
            tmp->setNeedsVia();
           // cout << "Via needed (M1->M2) at cell (" << tmpm << "," << tmpn << "," << tmpk << ") ---> (" << tmpm_dbu << "," << tmpn_dbu << ")" << endl;
        }
        else if (currk == 1 && tmpk == 2) { //change from layer 2 to layer 1
			//set via on tmp, which is M1.
        	curr->setNeedsVia2();
			// cout << "Via needed (M3->M2) at cell (" << tmpm << "," << tmpn << "," << tmpk << ") ---> (" << tmpm_dbu << "," << tmpn_dbu << ")" << endl;
        }
        else if (currk == 2 && tmpk == 1) { //change from layer 1 to layer 2
			//set via on tmp, which is M1.
			tmp->setNeedsVia2();
			// cout << "Via needed (M2->M3) at cell (" << tmpm << "," << tmpn << "," << tmpk << ") ---> (" << tmpm_dbu << "," << tmpn_dbu << ")" << endl;
		}
                
                int nRange;
              if (  (currk==0 && __metal_1_direction=='V') ||
                    (currk==1 && __metal_2_direction=='V') ||
                    (currk==2 && __metal_3_direction=='V') )
              {
                 //   if (
                 //(currk==0 && curr->needsVia()==false && curr->getStatus()!=CellContact)||
                 //(currk==1 && curr->needsVia2()==false && __grid->at(currm,currn,0)->needsVia()==false && curr->getStatus()!=CellContact )||
                 //(currk==2 && __grid->at(currm,currn,1)->needsVia2()==false && curr->getStatus()!=CellContact ) )
                   nRange=0;
                 //else
                 //   nRange=__Fattened_Width/2;
                    
                    for (int m=currm - __keepoutRadius_lateral; m<=currm + __keepoutRadius_lateral ; m++)
                    {
                        for (int n=currn - nRange; n<=currn + nRange ; n++)
                        {
                         Cell* testCell=__grid->at(m,n,currk); 
               
                         if (testCell->getStatus()==CellFree)
                          {
                          testCell->setStatus(CellKeepout);
                          //continue;
                          }
                        }
                    }
                 
             }
        
        tmp = curr;
        curr = curr->getBacktrace();
    }
}

void MazeRouter::generateKeepouts(oaUInt4 netID) {
	oaUInt4 dim_m,dim_n,dim_k = 0;
    __grid->getDims(&dim_m,&dim_n,&dim_k);// 152*314*3
   
   
    //Do by layer first
    for (oaUInt4 k = 0; k < dim_k; k++) 
    {
        for (oaUInt4 m = 0; m < dim_m; m++) 
        {
            for (oaUInt4 n = 0; n < dim_n; n++) 
            {
            
                Cell* curr = __grid->at(m,n,k);
                
                if (m==0 || n==0 || m==dim_m-1 || n==dim_n-1)
                {
                 curr->setStatus(CellKeepout);
                 continue;
                }
                
                CellStatus currStatus = curr->getStatus();
                
               // if (netID==5 && m==128 && n==68) cout<<"generateKeepouts(netID): "<<m<<" "<<n<<" "<<k<<" "<<"Status:"<<currStatus<<" NetID:"<<curr->getNetID()<<endl;
                switch (currStatus) {
                    case CellFilled: //keepout
                    case CellContact:
                    case CellVDDRail:
                    case CellVSSRail:
                        if (curr->getNetID() != netID)
                            generateKeepout(curr);                
                        break;
                    case CellKeepout: //do nothing
                        break;
                    case CellFree:
                        //Special keepouts for side of bounding box. Radius depends on which layer.
                        if (
                            (k == 0 && (m <= __keepoutRadius_bbox_m1 || m >= dim_m-__keepoutRadius_bbox_m1)) ||
                            (k == 1 && (m <= __keepoutRadius_bbox_m2 || m >= dim_m-__keepoutRadius_bbox_m2)) ||
							              (k == 2 && (m <= __keepoutRadius_bbox_m3 || m >= dim_m-__keepoutRadius_bbox_m3))
                           ) {
                         //   cout << "Keeping out n: " << n << " k: " << k << endl;
                                curr->setStatus(CellKeepout);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
}

void MazeRouter::generateKeepout(Cell* c) 
{

     oaUInt4 mtmp,ntmp,ktmp = 0;
    oaInt4 m,n,k = 0;
    oaUInt4 dim_m, dim_n, dim_k = 0;
    c->getPosition(&mtmp,&ntmp,&ktmp);
    m = mtmp;
    n = ntmp;
    k = ktmp;
    __grid->getDims(&dim_m, &dim_n, &dim_k);
    
    oaInt4 leftBound = 0;
    oaInt4 rightBound = 0;
    oaInt4 topBound = 0;
    oaInt4 bottomBound = 0;
    
    Cell* tmp = NULL;
    CellStatus tmpStatus;
    CellStatus cStatus = c->getStatus();
    
    Cell* c_left = NULL;
    Cell* c_right = NULL;
    Cell* c_up = NULL;
    Cell* c_down = NULL;
  
    c_left = (m-1>=0)? __grid->at(m-1,n,k) : NULL;
    c_right = (m+1<dim_m)? __grid->at(m+1,n,k) : NULL;
    c_up = (n+1<dim_n)? __grid->at(m,n+1,k) : NULL;
    c_down = (n-1>=0)? __grid->at(m,n-1,k) : NULL;
    
    Cell* c_lower = NULL;      
    c_lower = (k>=1) ? __grid->at(m,n,k-1):NULL;//lower level
    
    Cell* c_upper = NULL;
    c_upper = __grid->at(m,n,1);
    
     oaUInt4 cell_w, cell_h = 0; //assume width=height
    __grid->getCellDims(&cell_w, &cell_h);
    
    //int lateral;
    //int longitudinal;
    //cout<<"---------------In generateKeepout(Cell* c)!----------------------"<<endl;
             
             if (c->isSingleCell()==true) // Consider the case of a single contact
              {
                          oaInt4 IsolatedWid; // dbu
                          oaInt4 IsolatedExt; // dbu
                          
                       //   int Fattened_Width=(__rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule()>__rules->getMetalWidthRule()) ?        
                       //     __rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule() :
                       //     __rules->getMetalWidthRule();
                            
                         if (__rules->getMinMetalAreaRule()>=(__rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule())*(__rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule()) )
                         {
                    
                           IsolatedWid = (oaInt4)ceil(sqrt(__rules->getMinMetalAreaRule()));
                           IsolatedExt = (oaInt4)ceil(double(IsolatedWid)/2);
                         }
                         else//
                         {
                           IsolatedWid = __rules->getViaDimensionRule()+2*__rules->getContactViaExtensionRule();
                           IsolatedExt = (oaInt4)ceil(double(IsolatedWid)/2);
                         }
                 //leftBound = m-(IsolatedWid + __rules->getMetalSpaceRule())/cell_w;
                 leftBound = m - (oaInt4)ceil(double(IsolatedExt+double(__Fattened_Width_dbu)/2 + __rules->getMetalSpaceRule())/cell_w);
              		if (leftBound < 0)
              			leftBound = 0;
              
            		 //rightBound = m+(IsolatedWid + __rules->getMetalSpaceRule())/cell_w;
                 rightBound = m + (oaInt4)ceil(double(IsolatedExt+double(__Fattened_Width_dbu)/2 + __rules->getMetalSpaceRule())/cell_w);
              		if (rightBound > dim_m-1)
              			rightBound = dim_m-1;
                 
                 //bottomBound = n-(IsolatedWid + __rules->getMetalSpaceRule())/cell_w;
                 bottomBound = n - (oaInt4)ceil(double(IsolatedExt+double(__Fattened_Width_dbu)/2 + __rules->getMetalSpaceRule())/cell_w);
              		if (bottomBound < 0)
              			bottomBound = 0;
              
            		 //topBound = n+(IsolatedWid + __rules->getMetalSpaceRule())/cell_w;
                 topBound = n + (oaInt4)ceil(double(IsolatedExt+double(__Fattened_Width_dbu)/2 + __rules->getMetalSpaceRule())/cell_w);
              		if (topBound > dim_n-1)
              			topBound = dim_n-1;
                    
                 for (oaInt4 j = topBound; j >= bottomBound; j--) 
                   {
                       for (oaInt4 i = leftBound; i <= rightBound; i++) 
                       {
                           tmp = __grid->at(i,j,k);
                           if (tmp->getStatus() == CellFree)   
                               tmp->setStatus(CellKeepout);
                       }
                   }
                   
                 //  cout<<"-----------Test For Single Cell Extension----------------"<<endl;
                 //  cout<<" m: "<<m<<" n: "<<n<<" k: "<<k<<endl;
                 //  cout<<"IsolatedExt:"<<IsolatedExt<<" Fattened Width: "<<Fattened_Width/cell_w<<" __rules->getMetalSpaceRule(): "<<__rules->getMetalSpaceRule()/cell_w<<endl;
                 //  cout<<"leftBound: "<<leftBound<<" rightBound: "<<rightBound<<"bottomBound: "<<bottomBound<<"topBound:"<<topBound<<endl;
                   
                     return;
                 }


             
             // V direction
          if (  (k==0 && __metal_1_direction=='V')||
                (k==1 && __metal_2_direction=='V')||
                (k==2 && __metal_3_direction=='V') )
                {
                      leftBound = m-__keepoutRadius_lateral;
                          if (leftBound < 0)
                              leftBound = 0;
                          
                          rightBound = m+__keepoutRadius_lateral;
                          if (rightBound > dim_m-1)
                              rightBound = dim_m-1;
                          
                          //check line end top condition
                          if (n+1 < dim_n) 
                          {
                          //cout<<""<<endl;
                              tmp = __grid->at(m,n+1,k); //get cell above
                              tmpStatus = tmp->getStatus();
                              if (tmpStatus == CellFilled || tmpStatus == CellContact) //not line end
                                  topBound = n;
                              else 
                              { //line end
                                  if (cStatus == CellVDDRail || cStatus == CellVSSRail) //cell of interest is power rail
                                       topBound = n+__keepoutRadius_powerRail;
                                  else //cell of interest is regular net
                                       topBound = n+__keepoutRadius_longitudinal;
                              }
                              if (topBound > dim_n-1)
                                  topBound = dim_n-1;
                          }
                          
                          //check line end bottom condition
                          if (n-1 >= 0) 
                          {
                              tmp = __grid->at(m,n-1,k); //get cell below
                              tmpStatus = tmp->getStatus();
                              if (tmpStatus == CellFilled || tmpStatus == CellContact) //not line end
                                  bottomBound = n;
                              else { //line end
                                  if (cStatus == CellVDDRail || cStatus == CellVSSRail) //cell of interest is power rail
                                          bottomBound = n-__keepoutRadius_powerRail;
                                  else //cell of interest is regular net
                                          bottomBound = n-__keepoutRadius_longitudinal;
                              }
                              if (bottomBound < 0)
                                  bottomBound = 0;
                          }
                          for (oaInt4 j = topBound; j >= bottomBound; j--) {
                              for (oaInt4 i = leftBound; i <= rightBound; i++) {
                                  tmp = __grid->at(i,j,k);
                                  if (tmp->getStatus() == CellFree) {      
                                      tmp->setStatus(CellKeepout);
                                  }
                              }
                          }
                          
                 //  cout<<"--------------Debug Keepout Vertical-------------"<<endl;
                 //  cout<<" m: "<<m<<" n: "<<n<<" k: "<<k<<endl;                  
                 //  cout<<"leftBound: "<<leftBound<<" rightBound: "<<rightBound<<"bottomBound: "<<bottomBound<<"topBound:"<<topBound<<endl;
                 return;
                }// end of V direction
                
                // H direction   
          if (  (k==0 && __metal_1_direction=='H')||
                (k==1 && __metal_2_direction=='H')||
                (k==2 && __metal_3_direction=='H') )
                {
                          bottomBound = n-__keepoutRadius_lateral;
                            if (bottomBound < 0)
                                bottomBound = 0;
                            
                            topBound = n+__keepoutRadius_lateral;
                            if (topBound > dim_n-1)
                                topBound = dim_n-1;
                            
                            //check line end right condition
                            if (m+1 < dim_m) {
                                tmp = __grid->at(m+1,n,k); //get cell to right
                                tmpStatus = tmp->getStatus();
                                if (tmpStatus == CellFilled || tmpStatus == CellContact) //not line end
                                    rightBound = m;
                                else //line end
                                    rightBound = m+__keepoutRadius_longitudinal;
                                
                                if (rightBound > dim_m-1)
                                    rightBound = dim_m-1;
                            }
                            
                            //check line end left condition
                            if (m-1 >= 0) {
                                tmp = __grid->at(m-1,n,k); //get cell to left
                                tmpStatus = tmp->getStatus();
                                if (tmpStatus == CellFilled || tmpStatus == CellContact) //not line end
                                    leftBound = m;
                                else //line end
                                    leftBound = m-__keepoutRadius_longitudinal;
                                
                                if (leftBound < 0)
                                    leftBound = 0;
                            }
                            
                         for (oaInt4 j = topBound; j >= bottomBound; j--) {
                           for (oaInt4 i = leftBound; i <= rightBound; i++) {
                               tmp = __grid->at(i,j,k);
                               if (tmp->getStatus() == CellFree) {      
                                   tmp->setStatus(CellKeepout);
                               }
                           }
                       }

                  //  cout<<"--------------Debug Keepout Horizontal-------------"<<endl;
                  // cout<<" m: "<<m<<" n: "<<n<<" k: "<<k<<endl;                  
                  // cout<<"leftBound: "<<leftBound<<" rightBound: "<<rightBound<<"bottomBound: "<<bottomBound<<"topBound:"<<topBound<<endl;
                  return;
                }// end of H direction
                
                // B direction
          if (  (k==0 && __metal_1_direction=='B')||
                (k==1 && __metal_2_direction=='B')||
                (k==2 && __metal_3_direction=='B') )
                {
                      /*
                       if (m==0 || m==dim_m-1 || n==0 || n==dim_n-1)
                      {  
                        __grid->at(m,n,k)->setStatus(CellKeepout);
                        return;
                      }
                      */
                     if ( c_up->getStatus()==CellFilled || c_up->getStatus()==CellContact || c_down->getStatus()==CellFilled || c_down->getStatus()==CellContact )//Vertically aligned line segment
                     {
                     //cout<<m<<" "<<n<<" "<<k<<endl;
                           leftBound = m-__keepoutRadius_lateral;
                       		if (leftBound < 0)
                       			leftBound = 0;
                       
                       		rightBound = m+__keepoutRadius_lateral;
                       		if (rightBound > dim_m-1)
                       			rightBound = dim_m-1;
                       
                       		//check line end top condition
                       		if (n+1 < dim_n) 
                           {
                       			if (c_up->getStatus() == CellFilled || c_up->getStatus() == CellContact) //not line end
                       				topBound = n;
                       			else 
                             { //line end
                             
                               
                       				if (cStatus == CellVDDRail || cStatus == CellVSSRail) //cell of interest is power rail
                       					 topBound = n+__keepoutRadius_powerRail;
         
                               //else if ( (k==0 && (c->needsVia()==1 || cStatus==CellContact)) ||
                               //          (k==1 && (c->needsVia2()==1 || cStatus==CellContact || c_lower->needsVia()==1)) ||
                               //          (k==2 && (cStatus==CellContact || c_lower->needsVia2()==1)) ) //cell of interest is via or contact.
                               //   topBound = n+__keepoutRadius_longitudinal;
                                  
                       				else //cell of interest is regular net
                       					 topBound = n+__keepoutRadius_lateral;
                       			}
                       			if (topBound > dim_n-1)
                       				topBound = dim_n-1;
                       		}
                       
                       		//check line end bottom condition
                       		if (n-1 >= 0) 
                           {
         
                       			if (c_down->getStatus() == CellFilled || c_down->getStatus() == CellContact) //not line end
                       				bottomBound = n;
                       			else 
                             { //line end
                              
                       				if (cStatus == CellVDDRail || cStatus == CellVSSRail) //cell of interest is power rail
                       					 bottomBound = n-__keepoutRadius_powerRail;
         
                               //else if ( (k==0 && (c->needsVia()==1 || cStatus==CellContact)) ||
                               //          (k==1 && (c->needsVia2()==1 || cStatus==CellContact || c_lower->needsVia()==1)) ||
                               //          (k==2 && (cStatus==CellContact || c_lower->needsVia2()==1)) ) //cell of interest is via or contact.
                               //   bottomBound = n-__keepoutRadius_longitudinal;
                                  
                       				else //cell of interest is regular net
                       					 bottomBound = n-__keepoutRadius_lateral;
                       			}
                       			if (bottomBound < 0)
                       				bottomBound = 0;
                       		}
                         
                         for (oaInt4 j = topBound; j >= bottomBound; j--) 
                         {
                            for (oaInt4 i = leftBound; i <= rightBound; i++) 
                            {
                                tmp = __grid->at(i,j,k);
                                if (tmp->getStatus() == CellFree)     
                                    tmp->setStatus(CellKeepout);
         
                             }
                          }
                  // cout<<"--------------Debug Keepout Bidirectional (Vertical Segment)-------------"<<endl;
                  // cout<<" m: "<<m<<" n: "<<n<<" k: "<<k<<endl;                  
                  // cout<<"leftBound: "<<leftBound<<" rightBound: "<<rightBound<<"bottomBound: "<<bottomBound<<"topBound:"<<topBound<<endl;
         
                     }
                  else if(c_left->getStatus()==CellFilled || c_left->getStatus()==CellContact || c_right->getStatus()==CellFilled || c_right->getStatus()==CellContact)// Horizontally aligned line segment
                     {
             
                       		bottomBound = n-__keepoutRadius_lateral;
                       		if (bottomBound < 0)
                       			bottomBound = 0;
                       
                       		topBound = n+__keepoutRadius_lateral;
                       		if (topBound > dim_n-1)
                       			topBound = dim_n-1;
                       
                       		//check line end right condition
                       		if (m+1 < dim_m) 
                           {
                               //////////////////////////////////
                               if (c_right->getStatus() == CellFilled || c_right->getStatus() == CellContact) //not line end
                       				rightBound = m;
                       			// else 
                            // { //line end
                             // if ( (k==0 && (c->needsVia()==1 || cStatus==CellContact)) ||
                             //      (k==1 && (c->needsVia2()==1 || cStatus==CellContact || c_lower->needsVia()==1)) ||
                             //      (k==2 && (cStatus==CellContact || c_lower->needsVia2()==1)) ) //cell of interest is via or contact.
                          
                             //        rightBound = m+__keepoutRadius_longitudinal;
                                  
                       				else //cell of interest is regular net end
                       					 rightBound = m+__keepoutRadius_lateral;
                       			//}
                       			if (rightBound > dim_m-1)
                       				rightBound = dim_m-1;
                       		}
                       
                       		//check line end left condition
                       		if (m-1 >= 0) 
                           {
                               //////////////////////////////////
                               if (c_left->getStatus() == CellFilled || c_left->getStatus() == CellContact) //not line end
                       				  leftBound = m;
                       		//	else 
                          //   { //line end
                          //     if ( (k==0 && (c->needsVia()==1 || cStatus==CellContact)) ||
                          //          (k==1 && (c->needsVia2()==1 || cStatus==CellContact || c_lower->needsVia()==1)) ||
                          //          (k==2 && (cStatus==CellContact || c_lower->needsVia2()==1)) ) //cell of interest is via or contact.
                          //        leftBound = m-__keepoutRadius_longitudinal;
                                  
                       				else //cell of interest is regular net end
                       					 leftBound = m-__keepoutRadius_lateral;
                       			//}
                       			if (leftBound < 0)
                       				rightBound = 0;
                       		}
                          
                          
                          for (oaInt4 j = topBound; j >= bottomBound; j--) 
                            {
                                for (oaInt4 i = leftBound; i <= rightBound; i++) 
                                {
                                    tmp = __grid->at(i,j,k);
                                    if (tmp->getStatus() == CellFree)   
                                        tmp->setStatus(CellKeepout);
                                }
                            }
                  // cout<<"--------------Debug Keepout Bidirectional (Horizontal Segment)-------------"<<endl;
                  // cout<<" m: "<<m<<" n: "<<n<<" k: "<<k<<endl;                  
                  // cout<<"leftBound: "<<leftBound<<" rightBound: "<<rightBound<<"bottomBound: "<<bottomBound<<"topBound:"<<topBound<<endl;
                            
                       }
                return;
                }// end of B direction

}




