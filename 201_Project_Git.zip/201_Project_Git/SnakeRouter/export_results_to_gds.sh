#!/bin/bash
#
# This script exports routed results from the OA database to GDS files.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

ARGC=$# # Get the number of arguments excluding arg0 (the script itself). Check for help message condition.
if [[ "$ARGC" != 1 ]]; then # Bad number of arguments
    echo "Usage: export_results_to_gds.sh <PATH_TO_OA_DATABASE>"
    echo "This script must be run using the Bash shell."
    exit
fi

PATH_TO_OA_DATABASE=$1
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X1_routed_minrule output/AND2_X1_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X4_routed_minrule output/AND2_X4_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map DFF_X2_routed_minrule output/DFF_X2_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X1_routed_minrule output/INV_X1_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X32_routed_minrule output/INV_X32_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map LOGIC0_X1_routed_minrule output/LOGIC0_X1_routed_minrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map OAI21_X1_routed_minrule output/OAI21_X1_routed_minrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN1_routed_minrule output/HIDDEN1_routed_minrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN2_routed_minrule output/HIDDEN2_routed_minrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN3_routed_minrule output/HIDDEN3_routed_minrule.gds

./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X1_routed_interrule output/AND2_X1_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X4_routed_interrule output/AND2_X4_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map DFF_X2_routed_interrule output/DFF_X2_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X1_routed_interrule output/INV_X1_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X32_routed_interrule output/INV_X32_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map LOGIC0_X1_routed_interrule output/LOGIC0_X1_routed_interrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map OAI21_X1_routed_interrule output/OAI21_X1_routed_interrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN1_routed_interrule output/HIDDEN1_routed_interrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN2_routed_interrule output/HIDDEN2_routed_interrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN3_routed_interrule output/HIDDEN3_routed_interrule.gds

./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X1_routed_randrule output/AND2_X1_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X4_routed_randrule output/AND2_X4_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map DFF_X2_routed_randrule output/DFF_X2_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X1_routed_randrule output/INV_X1_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X32_routed_randrule output/INV_X32_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map LOGIC0_X1_routed_randrule output/LOGIC0_X1_routed_randrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map OAI21_X1_routed_randrule output/OAI21_X1_routed_randrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN1_routed_randrule output/HIDDEN1_routed_randrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN2_routed_randrule output/HIDDEN2_routed_randrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN3_routed_randrule output/HIDDEN3_routed_randrule.gds

./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X1_routed_maxrule output/AND2_X1_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map AND2_X4_routed_maxrule output/AND2_X4_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map DFF_X2_routed_maxrule output/DFF_X2_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X1_routed_maxrule output/INV_X1_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map INV_X32_routed_maxrule output/INV_X32_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map LOGIC0_X1_routed_maxrule output/LOGIC0_X1_routed_maxrule.gds
./oa2gds.sh $PATH_TO_OA_DATABASE layer.map OAI21_X1_routed_maxrule output/OAI21_X1_routed_maxrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN1_routed_maxrule output/HIDDEN1_routed_maxrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN2_routed_maxrule output/HIDDEN2_routed_maxrule.gds
#./oa2gds.sh $PATH_TO_OA_DATABASE layer.map HIDDEN3_routed_maxrule output/HIDDEN3_routed_maxrule.gds
