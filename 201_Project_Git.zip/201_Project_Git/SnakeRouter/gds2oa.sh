#!/bin/bash
#
# This script imports a single cell GDS into an OA database.
#
# Authors: Mark Gottscho and Yasmine Badr
# Email: mgottscho@ucla.edu, ybadr@ucla.edu
# Copyright (C) 2013 Mark Gottscho and Yasmine Badr

ARGC=$# # Get the number of arguments excluding arg0 (the script itself). Check for help message condition.
if [[ "$ARGC" != 3 ]]; then # Bad number of arguments
    echo "Usage: gds2oa.sh <OA_DATABASE_DIR> <LAYER_FILENAME> <INPUT_GDS_FILENAME>"
    echo "This script must be run using the Bash shell."
    exit
fi

OA_DATABASE_DIR=$1
LAYER_FILENAME=$2
INPUT_GDS_FILENAME=$3
strm2oa -lib $OA_DATABASE_DIR -gds $INPUT_GDS_FILENAME -layerMap "$LAYER_FILENAME"
